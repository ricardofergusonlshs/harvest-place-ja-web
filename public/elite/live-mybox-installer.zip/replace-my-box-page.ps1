# Run this from your project root:
# C:\Projects\harvest-place-ja-web\harvest-place-ja-web

$target = "src\app\my-box\page.tsx"
Copy-Item ".\my-box-page-live.tsx" $target -Force

Write-Host "Replaced $target"
Write-Host "Checking for test text..."
Select-String -Path $target -Pattern "MY BOX PAGE UPDATED"
Write-Host "Checking for old empty text..."
Select-String -Path $target -Pattern "Your box is empty"
Write-Host "Now run:"
Write-Host "Remove-Item -Recurse -Force .next"
Write-Host "npm run dev"
