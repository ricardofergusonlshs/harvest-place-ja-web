LIVE MY BOX INSTALLER

1. Extract both files into your project root:
   C:\Projects\harvest-place-ja-web\harvest-place-ja-web

2. In VS Code terminal, run:
   .\replace-my-box-page.ps1

3. Confirm both searches show no results:
   MY BOX PAGE UPDATED
   Your box is empty

4. Restart:
   Remove-Item -Recurse -Force .next
   npm run dev

5. Open:
   http://localhost:3000/my-box

This version refreshes from Supabase orders every 4 seconds.
