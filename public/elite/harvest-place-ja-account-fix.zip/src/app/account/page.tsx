'use client';

import Image from 'next/image';
import { useEffect, useMemo, useState, type ReactNode } from 'react';
import {
  Bell,
  Check,
  ChevronRight,
  Gift,
  Headphones,
  Heart,
  Home,
  Leaf,
  LockKeyhole,
  LogOut,
  MapPin,
  MessageCircle,
  PackageCheck,
  Pencil,
  ShieldCheck,
  ShoppingBag,
  Sparkles,
  Sprout,
  Truck,
  UserRound,
} from 'lucide-react';

import { Badge, Button, Card, EmptyState, LoadingState, StatusChip, cn } from '@/components/ui';
import { useAuth } from '@/components/providers/auth-provider';
import {
  fetchCurrentCustomerProfile,
  fetchCustomerProductSubscriptions,
  fetchLoyaltySummary,
  fetchOrders,
  fetchProducts,
  saveCurrentCustomerProfile,
} from '@/lib/services';
import { formatDate, formatJmd, safeEmailName, shortIdLabel } from '@/lib/format';
import type {
  CustomerProfile,
  CustomerProductSubscription,
  FarmOrder,
  LoyaltySummary,
  Product,
} from '@/lib/types';

const SIGN_IN_HREF = '/auth?redirect=/account';

const ACCOUNT_LINKS = [
  { label: 'Overview', href: '#overview', Icon: Home },
  { label: 'Orders', href: '#orders', Icon: PackageCheck },
  { label: 'My Box', href: '/my-box', Icon: ShoppingBag },
  { label: 'Fresh Alerts', href: '#fresh-alerts', Icon: Bell },
  { label: 'Delivery Details', href: '#delivery', Icon: MapPin },
  { label: 'Rewards', href: '#rewards', Icon: Gift },
  { label: 'Support', href: '#support', Icon: Headphones },
  { label: 'Profile Settings', href: '#settings', Icon: Pencil },
] as const;

type DashboardState = {
  profile: CustomerProfile | null;
  loyalty: LoyaltySummary;
  subs: CustomerProductSubscription[];
  orders: FarmOrder[];
  products: Product[];
};

type FarmSummary = {
  slug: string;
  farmName: string;
  parish: string;
  image: string;
  story: string;
  tags: string[];
  itemCount: number;
};

const emptyDashboard: DashboardState = {
  profile: null,
  loyalty: { points: 0, lifetime_points: 0, tier: 'Seedling' },
  subs: [],
  orders: [],
  products: [],
};

const offPlatformBlockedPhrases = [
  'call me',
  'text me',
  'whatsapp me',
  'whats app me',
  'send your number',
  'my number',
  'outside the app',
  'outside the website',
  'contact me directly',
  'message me directly',
  'dm me',
  'instagram',
  'facebook',
  'tiktok',
  'telegram',
];

export default function AccountPage() {
  const { user, loading: authLoading, farmerProfile, isAdmin, signOut } = useAuth();

  const [state, setState] = useState<DashboardState>(emptyDashboard);
  const [loading, setLoading] = useState(true);
  const [savingProfile, setSavingProfile] = useState(false);

  const [name, setName] = useState('');
  const [privateContact, setPrivateContact] = useState('');
  const [address, setAddress] = useState('');
  const [profileMessage, setProfileMessage] = useState('');

  const [supportDraft, setSupportDraft] = useState('');
  const [supportMessage, setSupportMessage] = useState('');

  useEffect(() => {
    let alive = true;

    async function load() {
      if (authLoading) return;

      if (!user) {
        setState(emptyDashboard);
        setLoading(false);
        return;
      }

      setLoading(true);

      const [profile, loyalty, subs, orders, products] = await Promise.all([
        safeResolve(fetchCurrentCustomerProfile(), null),
        safeResolve(
          fetchLoyaltySummary(),
          { points: 0, lifetime_points: 0, tier: 'Seedling' } as LoyaltySummary,
        ),
        safeResolve(fetchCustomerProductSubscriptions(), [] as CustomerProductSubscription[]),
        safeResolve(fetchOrders(), [] as FarmOrder[]),
        safeResolve(fetchProducts(), [] as Product[]),
      ]);

      if (!alive) return;

      setState({ profile, loyalty, subs, orders, products });
      setName(profile?.full_name || safeEmailName(user.email) || '');
      setPrivateContact(profile?.phone || '');
      setAddress(profile?.address || '');
      setLoading(false);
    }

    load();

    return () => {
      alive = false;
    };
  }, [user, authLoading]);

  const displayName = useMemo(
    () => name || state.profile?.full_name || safeEmailName(user?.email) || 'Harvest Customer',
    [name, state.profile?.full_name, user?.email],
  );

  const farms = useMemo(() => buildFarmSummaries(state.products), [state.products]);

  const points = Number(state.loyalty.points || 0);
  const lifetimePoints = Number(state.loyalty.lifetime_points || 0);
  const tier = state.loyalty.tier || 'Seedling';

  const orderTotal = state.orders.length;
  const alertTotal = state.subs.length;
  const recommendedProducts = state.products.slice(0, 4);

  const safetyScore = Math.min(100, 80 + Math.min(20, orderTotal * 4 + alertTotal * 3));

  const subscriptionsLabel = alertTotal
    ? `${alertTotal} fresh alert${alertTotal === 1 ? '' : 's'} active`
    : 'No fresh alerts yet';

  async function saveProfile() {
    if (savingProfile) return;

    setSavingProfile(true);
    setProfileMessage('Saving your profile...');

    try {
      await saveCurrentCustomerProfile({
        full_name: name || displayName,
        phone: privateContact,
        address,
      });

      setProfileMessage('Profile saved successfully. Your contact details remain private.');
    } catch (error) {
      setProfileMessage(error instanceof Error ? error.message : 'Profile could not be saved right now.');
    } finally {
      setSavingProfile(false);
    }
  }

  function checkSupportDraft() {
    const trimmed = supportDraft.trim();

    if (!trimmed) {
      setSupportMessage('Write a short message first.');
      return;
    }

    if (containsOffPlatformContact(trimmed)) {
      setSupportMessage(
        'For safety, remove phone numbers, emails, links, social handles, or direct-contact phrases.',
      );
      return;
    }

    setSupportMessage('This message looks safe. Next, connect this composer to the shared Supabase inbox.');
  }

  if (authLoading || loading) {
    return (
      <main className="mx-auto max-w-[1700px] px-4 py-10 sm:px-6 lg:px-10">
        <LoadingState />
      </main>
    );
  }

  if (!user) {
    return (
      <main className="min-h-screen bg-[linear-gradient(180deg,#FAF8F0_0%,#F4F9F2_60%,#FFFEFC_100%)] px-4 py-12 text-[#183B28] sm:px-6 lg:px-8">
        <div className="mx-auto max-w-5xl">
          <EmptyState
            title="Sign in to manage your Harvest Place account"
            subtitle="View your orders, manage fresh alerts, update delivery details, save your profile, and contact support safely inside The Harvest Place Ja."
            action={
              <div className="flex flex-wrap justify-center gap-3">
                <Button href={SIGN_IN_HREF}>Sign in</Button>
                <Button href="/shop" variant="secondary">
                  Continue shopping
                </Button>
              </div>
            }
          />
        </div>
      </main>
    );
  }

  return (
    <main className="min-h-screen bg-[linear-gradient(180deg,#FAF8F0_0%,#F4F9F2_52%,#FFFEFC_100%)] text-[#183B28]">
      <div className="mx-auto max-w-[1700px] px-4 py-8 sm:px-6 lg:px-10">
        <div className="grid gap-6 xl:grid-cols-[270px_1fr]">
          <AccountSidebar
            isAdmin={isAdmin}
            farmerStatus={farmerProfile?.verification_status}
            onSignOut={signOut}
          />

          <div className="grid gap-6">
            <section id="overview" className="scroll-mt-32 grid gap-6 2xl:grid-cols-[1.35fr_0.82fr_0.82fr]">
              <WelcomeCard displayName={displayName} userEmail={user.email} />
              <AccountSummaryCard orders={orderTotal} alerts={alertTotal} points={points} />
              <SafetyCard score={safetyScore} />
            </section>

            <section className="grid gap-6 xl:grid-cols-[1.2fr_0.8fr]">
              <MyBoxCard />
              <FreshAlertCard alertTotal={alertTotal} subscriptionsLabel={subscriptionsLabel} />
            </section>

            <section id="orders" className="scroll-mt-32 grid gap-6 xl:grid-cols-[1.2fr_0.8fr]">
              <RecentOrdersCard orders={state.orders} />
              <RecommendedProduceCard products={recommendedProducts} />
            </section>

            <section id="fresh-alerts" className="scroll-mt-32 grid gap-6 xl:grid-cols-[1.2fr_0.8fr]">
              <SuggestedFarmsCard farms={farms} />
              <RewardsCard tier={tier} points={points} lifetimePoints={lifetimePoints} />
            </section>

            <section id="delivery" className="scroll-mt-32 grid gap-6 xl:grid-cols-[1.05fr_0.95fr]">
              <SavedDeliveryCard profile={state.profile} address={address} />
              <TrustSecurityCard />
            </section>

            <section id="support" className="scroll-mt-32 grid gap-6 xl:grid-cols-[1.05fr_0.95fr]">
              <SupportMessageCard
                value={supportDraft}
                message={supportMessage}
                onChange={setSupportDraft}
                onSubmit={checkSupportDraft}
              />
              <SupportCard />
            </section>

            <section id="settings" className="scroll-mt-32 grid gap-6 xl:grid-cols-[1.1fr_0.9fr]">
              <ProfileSettingsCard
                name={name}
                privateContact={privateContact}
                address={address}
                message={profileMessage}
                saving={savingProfile}
                onName={setName}
                onPrivateContact={setPrivateContact}
                onAddress={setAddress}
                onSave={saveProfile}
              />

              <AccessCard
                email={user.email}
                isAdmin={isAdmin}
                farmerStatus={farmerProfile?.verification_status}
                subscriptionsLabel={subscriptionsLabel}
                points={points}
              />
            </section>
          </div>
        </div>
      </div>
    </main>
  );
}

async function safeResolve<T>(promise: Promise<T>, fallback: T, timeoutMs = 18000): Promise<T> {
  try {
    return await Promise.race([
      promise,
      new Promise<T>((resolve) => window.setTimeout(() => resolve(fallback), timeoutMs)),
    ]);
  } catch (error) {
    console.error('Account data load failed:', error);
    return fallback;
  }
}

function containsOffPlatformContact(message: string) {
  const text = message.toLowerCase();
  const phonePattern = /(\+?\d[\d\s().-]{6,}\d)/;
  const emailPattern = /[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}/i;
  const linkPattern = /(https?:\/\/|www\.|\.com|\.net|\.org|\.co|wa\.me|whatsapp|instagram|facebook|tiktok|telegram)/i;
  const socialHandlePattern = /(^|\s)@[a-z0-9._-]{3,}/i;

  return (
    phonePattern.test(text) ||
    emailPattern.test(text) ||
    linkPattern.test(text) ||
    socialHandlePattern.test(text) ||
    offPlatformBlockedPhrases.some((phrase) => text.includes(phrase))
  );
}

function makeFarmSlug(value: unknown) {
  return (
    String(value ?? 'local-farm')
      .toLowerCase()
      .trim()
      .replace(/&/g, 'and')
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '') || 'local-farm'
  );
}

function productFarmName(product: Product) {
  const item = product as Product & {
    farm_name?: string | null;
    farmer_name?: string | null;
  };

  return item.farm_name || item.farmer_name || 'Local Partner Farm';
}

function productParish(product: Product) {
  const item = product as Product & {
    parish?: string | null;
  };

  return item.parish || 'Jamaica';
}

function productCategory(product: Product) {
  const item = product as Product & {
    category?: string | null;
  };

  return item.category || 'Fresh Produce';
}

function buildFarmSummaries(products: Product[]): FarmSummary[] {
  if (!products.length) return [];

  const grouped = new Map<string, FarmSummary>();

  products.forEach((product) => {
    const farmName = productFarmName(product);
    const slug = makeFarmSlug(farmName);
    const existing = grouped.get(slug);
    const tag = productCategory(product);

    if (existing) {
      existing.itemCount += 1;
      if (!existing.tags.includes(tag)) existing.tags.push(tag);
      return;
    }

    grouped.set(slug, {
      slug,
      farmName,
      parish: productParish(product),
      image: product.image_url || '/logo.png',
      story: 'View available produce, harvest updates, and safe platform support from this local partner.',
      tags: [tag, 'Local Produce', 'Platform Support'],
      itemCount: 1,
    });
  });

  return Array.from(grouped.values()).slice(0, 6);
}

function getOrderStatus(order: FarmOrder) {
  const item = order as FarmOrder & {
    delivery_status?: string | null;
    order_status?: string | null;
    status?: string | null;
  };

  return item.delivery_status || item.order_status || item.status || 'pending';
}

function getOrderTotal(order: FarmOrder) {
  const item = order as FarmOrder & {
    total_amount?: number | null;
    grand_total?: number | null;
    total?: number | null;
    subtotal?: number | null;
  };

  return item.total_amount ?? item.grand_total ?? item.total ?? item.subtotal ?? null;
}

function getFulfillmentLabel(order: FarmOrder) {
  const item = order as FarmOrder & {
    fulfillment_type?: string | null;
    delivery_method?: string | null;
  };

  return item.fulfillment_type || item.delivery_method || 'Fulfillment pending';
}

function AccountSidebar({
  isAdmin,
  farmerStatus,
  onSignOut,
}: {
  isAdmin: boolean;
  farmerStatus?: string | null;
  onSignOut: () => Promise<void> | void;
}) {
  return (
    <aside className="rounded-[2rem] border border-[#D8E5D4] bg-white/95 p-4 shadow-[0_22px_70px_rgba(24,59,40,0.08)] xl:sticky xl:top-32 xl:self-start">
      <p className="px-3 py-2 text-xs font-black uppercase tracking-[0.18em] text-[#183B28]">
        My Account
      </p>

      <div className="mt-2 grid gap-1">
        {ACCOUNT_LINKS.map(({ label, href, Icon }, index) => (
          <a
            key={label}
            href={href}
            className={cn(
              'relative flex items-center gap-3 rounded-2xl px-4 py-3 text-left text-sm font-extrabold text-[#5F6A62] transition hover:bg-[#EAF5E7] hover:text-[#183B28]',
              index === 0 &&
                'bg-[#EAF5E7] text-[#183B28] before:absolute before:left-0 before:top-2 before:h-8 before:w-1 before:rounded-r-full before:bg-[#2D6741]',
            )}
          >
            <Icon className="h-4 w-4" />
            {label}
          </a>
        ))}

        {isAdmin ? (
          <a
            href="/admin"
            className="flex items-center gap-3 rounded-2xl px-4 py-3 text-left text-sm font-extrabold text-[#5F6A62] transition hover:bg-[#FFF3D9] hover:text-[#183B28]"
          >
            <ShieldCheck className="h-4 w-4" />
            Admin Dashboard
          </a>
        ) : null}

        <button
          type="button"
          onClick={onSignOut}
          className="flex items-center gap-3 rounded-2xl px-4 py-3 text-left text-sm font-extrabold text-[#5F6A62] transition hover:bg-[#FFF3D9] hover:text-[#183B28]"
        >
          <LogOut className="h-4 w-4" />
          Sign out
        </button>
      </div>

      <div className="mt-6 overflow-hidden rounded-[1.5rem] border border-[#D8E5D4] bg-[#EAF5E7] p-4">
        <p className="text-base font-black leading-tight text-[#183B28]">
          Fresh, local, simple.
        </p>

        <p className="mt-2 text-xs font-semibold leading-5 text-[#5F6A62]">
          Manage your orders, fresh alerts, delivery details, rewards, and support in one place.
        </p>

        <div className="mt-4 flex items-end justify-between gap-3">
          <div>
            <Badge tone={isAdmin ? 'gold' : 'green'}>
              {isAdmin ? 'Admin access' : farmerStatus || 'Customer account'}
            </Badge>

            <p className="mt-3 text-[11px] font-black text-[#183B28]">
              Platform-safe support
            </p>
          </div>

          <div className="relative h-20 w-20 overflow-hidden rounded-2xl bg-white shadow-sm">
            <Image src="/logo.png" alt="The Harvest Place Ja" fill className="object-contain p-2" sizes="80px" />
          </div>
        </div>
      </div>
    </aside>
  );
}

function WelcomeCard({ displayName, userEmail }: { displayName: string; userEmail?: string }) {
  return (
    <Card className="relative min-h-[230px] overflow-hidden border-[#D8E5D4] bg-white p-0 shadow-[0_22px_70px_rgba(24,59,40,0.08)]">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_75%_22%,rgba(223,167,90,0.22),transparent_18rem),linear-gradient(90deg,#fff_0%,rgba(255,255,255,0.96)_48%,rgba(234,245,231,0.45)_100%)]" />

      <div className="absolute right-0 top-0 hidden h-full w-1/2 opacity-95 md:block">
        <div className="absolute inset-0 bg-gradient-to-r from-white via-white/70 to-transparent" />
        <Image src="/logo.png" alt="The Harvest Place Ja" fill className="object-contain p-10 opacity-20" sizes="480px" />
      </div>

      <div className="relative z-10 p-7 lg:p-8">
        <p className="text-sm font-bold text-[#5F6A62]">Welcome back,</p>

        <h1 className="mt-1 text-3xl font-black tracking-tight text-[#183B28] lg:text-4xl">
          {displayName || 'Harvest Customer'}
        </h1>

        <div className="mt-2 flex flex-wrap items-center gap-2 text-sm font-black text-[#DFA75A]">
          <Sparkles className="h-4 w-4" />
          The Harvest Place Ja account
        </div>

        <p className="mt-4 max-w-md text-sm font-semibold leading-6 text-[#5F6A62]">
          Manage your fresh produce orders, weekly box activity, ready-soon alerts, support messages,
          and private delivery details.
        </p>

        <div className="mt-6 flex flex-wrap gap-3">
          <Button href="/shop">Shop Produce</Button>
          <Button href="/my-box" variant="secondary" className="border-[#DFA75A]/45 bg-white/75">
            View My Box
          </Button>
          <Badge tone="green">{userEmail || 'Secure customer account'}</Badge>
        </div>
      </div>
    </Card>
  );
}

function AccountSummaryCard({
  orders,
  alerts,
  points,
}: {
  orders: number;
  alerts: number;
  points: number;
}) {
  return (
    <Card className="border-[#D8E5D4] bg-white p-7 shadow-[0_18px_55px_rgba(24,59,40,0.07)]">
      <div className="flex items-start gap-4">
        <div className="grid h-12 w-12 place-items-center rounded-full border border-[#D8E5D4] bg-[#EAF5E7] text-[#2D6741]">
          <Leaf className="h-6 w-6" />
        </div>

        <div>
          <p className="text-sm font-bold text-[#5F6A62]">Account Summary</p>
          <h2 className="mt-1 text-2xl font-black text-[#183B28]">Your activity</h2>
        </div>
      </div>

      <div className="mt-6 grid grid-cols-3 gap-3 text-center">
        <MiniStat value={orders} label="Orders" />
        <MiniStat value={alerts} label="Alerts" />
        <MiniStat value={points} label="Points" />
      </div>

      <Button href="/orders" variant="secondary" className="mt-5 w-full border-[#D8E5D4]">
        View Orders
      </Button>
    </Card>
  );
}

function SafetyCard({ score }: { score: number }) {
  return (
    <Card className="border-[#F0D6A7] bg-gradient-to-br from-[#FFF3D9] via-white to-white p-7 shadow-[0_18px_55px_rgba(24,59,40,0.07)]">
      <div className="flex items-start gap-4">
        <div className="grid h-12 w-12 place-items-center rounded-full bg-white text-[#2D6741] shadow-sm">
          <ShieldCheck className="h-6 w-6" />
        </div>

        <div>
          <p className="text-sm font-black text-[#183B28]">Safe account flow</p>
          <h2 className="mt-1 text-2xl font-black text-[#183B28]">{score}% ready</h2>
        </div>
      </div>

      <p className="mt-4 text-sm font-semibold leading-6 text-[#5F6A62]">
        Orders, support, and future customer-farmer messages should stay inside the platform.
      </p>

      <div className="mt-5 h-2 overflow-hidden rounded-full bg-[#EAF5E7]">
        <div className="h-full rounded-full bg-[#2D6741]" style={{ width: `${score}%` }} />
      </div>
    </Card>
  );
}

function MyBoxCard() {
  return (
    <Card className="border-[#D8E5D4] bg-white p-6 lg:p-7 shadow-[0_18px_55px_rgba(24,59,40,0.07)]">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <p className="text-[11px] font-black uppercase tracking-[0.22em] text-[#DFA75A]">
            Shopping basket
          </p>

          <h2 className="mt-1 text-2xl font-black tracking-[-0.035em] text-[#183B28]">
            Continue building your box
          </h2>

          <p className="mt-2 max-w-2xl text-sm font-semibold leading-6 text-[#5F6A62]">
            Add fresh produce, review quantities, and checkout when your box is ready.
          </p>
        </div>

        <div className="grid h-16 w-16 place-items-center rounded-3xl bg-[#EAF5E7] text-[#2D6741]">
          <ShoppingBag className="h-8 w-8" />
        </div>
      </div>

      <div className="mt-6 flex flex-wrap gap-3">
        <Button href="/my-box">View My Box</Button>
        <Button href="/shop" variant="secondary" className="border-[#D8E5D4]">
          Continue Shopping
        </Button>
      </div>
    </Card>
  );
}

function FreshAlertCard({
  alertTotal,
  subscriptionsLabel,
}: {
  alertTotal: number;
  subscriptionsLabel: string;
}) {
  return (
    <Card className="border-[#D8E5D4] bg-white p-6 shadow-[0_18px_55px_rgba(24,59,40,0.07)]">
      <div className="flex items-start gap-4">
        <div className="grid h-12 w-12 place-items-center rounded-full bg-[#EAF5E7] text-[#2D6741]">
          <Bell className="h-6 w-6" />
        </div>

        <div>
          <p className="text-sm font-bold text-[#5F6A62]">Ready Soon Alerts</p>

          <h2 className="mt-1 text-2xl font-black text-[#183B28]">
            {alertTotal || 'No'} active alert{alertTotal === 1 ? '' : 's'}
          </h2>
        </div>
      </div>

      <p className="mt-4 text-sm font-semibold leading-6 text-[#5F6A62]">
        {subscriptionsLabel}. Get notified when selected produce becomes available.
      </p>

      <Button href="/ready-soon" variant="secondary" className="mt-5 w-full border-[#D8E5D4]">
        Manage Fresh Alerts
      </Button>
    </Card>
  );
}

function RecentOrdersCard({ orders }: { orders: FarmOrder[] }) {
  const visible = orders.slice(0, 3);

  return (
    <Card className="border-[#D8E5D4] bg-white p-6 lg:p-7 shadow-[0_18px_55px_rgba(24,59,40,0.07)]">
      <div className="mb-5 flex items-center justify-between gap-4">
        <div>
          <p className="text-[11px] font-black uppercase tracking-[0.22em] text-[#DFA75A]">
            Order activity
          </p>

          <h2 className="text-xl font-black text-[#183B28]">Recent orders</h2>
        </div>

        <Button href="/orders" variant="ghost" className="px-3 py-2">
          View All
        </Button>
      </div>

      {visible.length ? (
        <div className="grid gap-4">
          {visible.map((order) => (
            <OrderCard key={order.id} order={order} />
          ))}
        </div>
      ) : (
        <div className="rounded-[1.5rem] border border-dashed border-[#D8E5D4] bg-[#EAF5E7]/35 p-8 text-center">
          <div className="mx-auto grid h-14 w-14 place-items-center rounded-full bg-white text-[#2D6741] shadow-sm">
            <PackageCheck className="h-6 w-6" />
          </div>

          <h3 className="mt-4 text-lg font-black text-[#183B28]">No orders yet</h3>

          <p className="mt-2 text-sm font-semibold text-[#5F6A62]">
            Start shopping, add items to My Box, and your orders will appear here.
          </p>

          <Button href="/shop" className="mt-5">
            Shop Produce
          </Button>
        </div>
      )}
    </Card>
  );
}

function OrderCard({ order }: { order: FarmOrder }) {
  const status = getOrderStatus(order);
  const total = getOrderTotal(order);

  return (
    <div className="rounded-[1.35rem] border border-[#D8E5D4] bg-white p-5 shadow-[0_10px_35px_rgba(24,59,40,0.05)]">
      <div className="flex flex-col gap-3 md:flex-row md:items-start md:justify-between">
        <div>
          <div className="flex flex-wrap items-center gap-2">
            <h3 className="text-lg font-black text-[#183B28]">
              Order #HPJ-{shortIdLabel(order.id)}
            </h3>
            <StatusChip status={status} />
          </div>

          <p className="mt-2 text-xs font-bold text-[#5F6A62]">
            {formatDate(order.created_at)} • {getFulfillmentLabel(order)} •{' '}
            {typeof total === 'number' ? formatJmd(total) : 'Total pending'}
          </p>
        </div>

        <ChevronRight className="hidden h-5 w-5 text-[#5F6A62] md:block" />
      </div>

      <OrderTimeline status={status} />

      <div className="mt-4 flex flex-wrap gap-2">
        <Button href={`/orders/${order.id}`} className="px-5 py-2.5">
          View Order
        </Button>

        <Button href="/support" variant="secondary" className="px-5 py-2.5">
          Get Help
        </Button>
      </div>
    </div>
  );
}

function OrderTimeline({ status }: { status: string }) {
  const steps = ['Placed', 'Preparing', 'Ready', 'Completed'];
  const lower = status.toLowerCase();

  const active =
    lower.includes('deliver') || lower.includes('complete')
      ? 3
      : lower.includes('ready') || lower.includes('pickup')
        ? 2
        : lower.includes('prepar') || lower.includes('pack')
          ? 1
          : 0;

  return (
    <div className="mt-5 grid grid-cols-4 gap-2">
      {steps.map((step, index) => (
        <div key={step} className="text-center">
          <div
            className={cn(
              'mx-auto grid h-7 w-7 place-items-center rounded-full border text-[11px] font-black',
              index <= active
                ? 'border-[#2D6741] bg-[#2D6741] text-white'
                : 'border-[#D8E5D4] bg-white text-[#5F6A62]',
            )}
          >
            {index <= active ? <Check className="h-3.5 w-3.5" /> : index + 1}
          </div>

          <p
            className={cn(
              'mt-1 hidden text-[10px] font-black md:block',
              index <= active ? 'text-[#183B28]' : 'text-[#5F6A62]',
            )}
          >
            {step}
          </p>
        </div>
      ))}
    </div>
  );
}

function RecommendedProduceCard({ products }: { products: Product[] }) {
  return (
    <Card className="border-[#D8E5D4] bg-white p-6 shadow-[0_18px_55px_rgba(24,59,40,0.07)]">
      <div className="mb-4 flex items-center justify-between">
        <h2 className="font-black text-[#183B28]">Recommended Produce</h2>
        <Button href="/shop" variant="ghost" className="px-3 py-2 text-xs">
          Shop
        </Button>
      </div>

      {products.length ? (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4 xl:grid-cols-2 2xl:grid-cols-4">
          {products.slice(0, 4).map((product) => (
            <div
              key={product.id}
              className="relative rounded-2xl border border-[#D8E5D4] bg-white p-2 text-center"
            >
              <Heart className="absolute right-2 top-2 h-3.5 w-3.5 text-[#DFA75A]" />

              <div className="relative mx-auto h-16 w-full overflow-hidden rounded-xl bg-[#EAF5E7]">
                <Image
                  src={product.image_url || '/logo.png'}
                  alt={product.name}
                  fill
                  className="object-cover"
                  sizes="90px"
                />
              </div>

              <p className="mt-2 truncate text-[11px] font-black text-[#183B28]">
                {product.name}
              </p>

              <p className="truncate text-[10px] font-bold text-[#5F6A62]">
                {productFarmName(product)}
              </p>
            </div>
          ))}
        </div>
      ) : (
        <div className="rounded-[1.5rem] border border-dashed border-[#D8E5D4] bg-[#EAF5E7]/35 p-6 text-center">
          <ShoppingBag className="mx-auto h-8 w-8 text-[#2D6741]" />
          <p className="mt-3 text-sm font-black text-[#183B28]">No recommended produce yet</p>
          <p className="mt-1 text-xs font-semibold text-[#5F6A62]">
            Add products to the marketplace and recommendations will appear here.
          </p>
        </div>
      )}
    </Card>
  );
}

function SuggestedFarmsCard({ farms }: { farms: FarmSummary[] }) {
  return (
    <Card className="border-[#D8E5D4] bg-white p-6 lg:p-7 shadow-[0_18px_55px_rgba(24,59,40,0.07)]">
      <div className="mb-5 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="text-[11px] font-black uppercase tracking-[0.22em] text-[#DFA75A]">
            Local producer view
          </p>

          <h2 className="mt-1 text-2xl font-black tracking-[-0.035em] text-[#183B28]">
            Suggested farms & producers
          </h2>

          <p className="mt-2 max-w-2xl text-sm font-semibold leading-6 text-[#5F6A62]">
            These suggestions are based on products currently available in the marketplace.
          </p>
        </div>

        <Button href="/farmer" variant="secondary" className="border-[#D8E5D4]">
          Explore Farms
        </Button>
      </div>

      {farms.length ? (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {farms.slice(0, 6).map((farm) => (
            <FarmCard key={farm.slug} farm={farm} />
          ))}
        </div>
      ) : (
        <div className="rounded-[1.5rem] border border-dashed border-[#D8E5D4] bg-[#EAF5E7]/35 p-8 text-center">
          <div className="mx-auto grid h-14 w-14 place-items-center rounded-full bg-white text-[#2D6741] shadow-sm">
            <Leaf className="h-6 w-6" />
          </div>

          <h3 className="mt-4 text-lg font-black text-[#183B28]">
            No farm profiles available yet
          </h3>

          <p className="mt-2 text-sm font-semibold text-[#5F6A62]">
            Once products are connected to farms, suggested producers will appear here.
          </p>

          <Button href="/shop" className="mt-5">
            Browse Produce
          </Button>
        </div>
      )}
    </Card>
  );
}

function FarmCard({ farm }: { farm: FarmSummary }) {
  return (
    <article className="overflow-hidden rounded-[26px] border border-[#D8E5D4] bg-[#FFFEFC] shadow-[0_14px_38px_rgba(24,59,40,0.06)]">
      <div className="relative h-36 bg-[#EAF5E7]">
        <Image src={farm.image} alt={farm.farmName} fill className="object-cover" sizes="340px" />
        <div className="absolute inset-x-0 top-0 h-20 bg-gradient-to-b from-black/30 to-transparent" />

        <span className="absolute right-3 top-3 rounded-full bg-white/90 px-3 py-1 text-[10px] font-black text-[#2D6741] shadow-sm">
          {farm.itemCount} item{farm.itemCount === 1 ? '' : 's'}
        </span>
      </div>

      <div className="p-4">
        <div className="flex items-start justify-between gap-3">
          <div>
            <h3 className="text-lg font-black tracking-[-0.02em] text-[#183B28]">
              {farm.farmName}
            </h3>

            <p className="mt-1 inline-flex items-center gap-1.5 text-xs font-black text-[#5F6A62]">
              <MapPin className="h-3.5 w-3.5 text-[#2D6741]" />
              {farm.parish}
            </p>
          </div>

          <Heart className="h-5 w-5 text-[#DFA75A]" />
        </div>

        <p className="mt-3 line-clamp-2 text-sm font-semibold leading-6 text-[#5F6A62]">
          {farm.story}
        </p>

        <div className="mt-4 flex flex-wrap gap-2">
          {farm.tags.slice(0, 3).map((tag) => (
            <span
              key={`${farm.slug}-${tag}`}
              className="rounded-full bg-[#EAF5E7] px-3 py-1 text-[10px] font-black text-[#2D6741]"
            >
              {tag}
            </span>
          ))}
        </div>

        <div className="mt-5 grid gap-2">
          <Button href="/farmer" className="w-full">
            View Farms
          </Button>

          <Button href="/ready-soon" variant="secondary" className="border-[#F0D6A7] bg-[#FFF3D9] px-3 py-2 text-[11px]">
            Manage Fresh Alerts
          </Button>
        </div>
      </div>
    </article>
  );
}

function RewardsCard({
  tier,
  points,
  lifetimePoints,
}: {
  tier: string;
  points: number;
  lifetimePoints: number;
}) {
  return (
    <Card id="rewards" className="scroll-mt-32 border-[#D8E5D4] bg-white p-6 shadow-[0_18px_55px_rgba(24,59,40,0.07)]">
      <div className="flex items-start gap-4">
        <div className="grid h-12 w-12 place-items-center rounded-full bg-[#FFF3D9] text-[#8B5D18]">
          <Gift className="h-6 w-6" />
        </div>

        <div>
          <p className="text-sm font-bold text-[#5F6A62]">Rewards & Points</p>
          <h2 className="mt-1 text-2xl font-black text-[#183B28]">{tier}</h2>
        </div>
      </div>

      <div className="mt-6 grid grid-cols-2 gap-3">
        <MiniStat value={points} label="Current" />
        <MiniStat value={lifetimePoints} label="Lifetime" />
      </div>

      <p className="mt-4 rounded-2xl bg-[#EAF5E7] px-4 py-3 text-xs font-bold leading-5 text-[#2D6741]">
        Rewards can be expanded later for repeat customers, weekly box subscriptions, and referral bonuses.
      </p>
    </Card>
  );
}

function SavedDeliveryCard({
  profile,
  address,
}: {
  profile: CustomerProfile | null;
  address: string;
}) {
  return (
    <Card className="border-[#D8E5D4] bg-white p-6 shadow-[0_18px_55px_rgba(24,59,40,0.07)]">
      <div className="mb-4 flex items-center justify-between">
        <h2 className="font-black text-[#183B28]">Delivery & Pickup Details</h2>
        <Badge tone="green">Private</Badge>
      </div>

      <AddressBlock
        label="Primary delivery area"
        badge="Private"
        address={address || profile?.address || 'Add your delivery parish, district, or pickup preference in profile settings.'}
      />

      <AddressBlock
        label="Pickup preference"
        address="Farm pickup and delivery preferences can be added here later."
        muted
      />

      <p className="mt-4 rounded-2xl bg-[#EAF5E7] px-4 py-3 text-xs font-bold leading-5 text-[#2D6741]">
        Delivery details are used for customer support and order planning. They are not displayed publicly.
      </p>
    </Card>
  );
}

function AddressBlock({
  label,
  badge,
  address,
  muted = false,
}: {
  label: string;
  badge?: string;
  address: string;
  muted?: boolean;
}) {
  return (
    <div
      className={cn(
        'mt-3 rounded-2xl border border-[#D8E5D4] bg-white p-4',
        muted && 'border-dashed bg-[#EAF5E7]/30',
      )}
    >
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <p className="text-sm font-black text-[#183B28]">{label}</p>
          {badge ? (
            <Badge tone="green" className="py-0.5 text-[10px]">
              {badge}
            </Badge>
          ) : null}
        </div>

        <Pencil className="h-4 w-4 text-[#5F6A62]" />
      </div>

      <p className="mt-2 whitespace-pre-line text-sm font-semibold leading-5 text-[#5F6A62]">
        {address}
      </p>
    </div>
  );
}

function TrustSecurityCard() {
  return (
    <Card className="relative overflow-hidden border-[#D8E5D4] bg-white p-6 shadow-[0_18px_55px_rgba(24,59,40,0.07)]">
      <div className="absolute right-4 top-6 grid h-24 w-24 place-items-center rounded-full bg-[#EAF5E7] text-[#2D6741]">
        <ShieldCheck className="h-12 w-12" />
      </div>

      <h2 className="font-black text-[#183B28]">Trust & Safety</h2>

      <p className="mt-2 max-w-xl pr-24 text-sm font-semibold leading-6 text-[#5F6A62]">
        For safety, order help, delivery issues, and future farm messages should stay inside The Harvest Place Ja.
      </p>

      <div className="mt-6 grid gap-4 pr-20 sm:grid-cols-2">
        <TrustLine
          icon={<LockKeyhole className="h-5 w-5" />}
          title="Private details protected"
          copy="Phone and delivery details are not displayed publicly."
        />
        <TrustLine
          icon={<MessageCircle className="h-5 w-5" />}
          title="Support stays tracked"
          copy="Live chat and inbox messages should use the shared Supabase tables."
        />
        <TrustLine
          icon={<Truck className="h-5 w-5" />}
          title="Delivery-ready"
          copy="Delivery and pickup details can support future order workflows."
        />
        <TrustLine
          icon={<Sprout className="h-5 w-5" />}
          title="Local farm focus"
          copy="Customers can explore real available produce from local partners."
        />
      </div>
    </Card>
  );
}

function SupportMessageCard({
  value,
  message,
  onChange,
  onSubmit,
}: {
  value: string;
  message: string;
  onChange: (value: string) => void;
  onSubmit: () => void;
}) {
  const unsafe = Boolean(value.trim()) && containsOffPlatformContact(value);

  return (
    <Card className="border-[#D8E5D4] bg-white p-6 lg:p-7 shadow-[0_18px_55px_rgba(24,59,40,0.07)]">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <p className="text-[11px] font-black uppercase tracking-[0.22em] text-[#DFA75A]">
            Support message
          </p>

          <h2 className="mt-1 text-2xl font-black tracking-[-0.035em] text-[#183B28]">
            Check a support message
          </h2>

          <p className="mt-2 max-w-2xl text-sm font-semibold leading-6 text-[#5F6A62]">
            This safety checker helps prevent private contact sharing. The live chat widget can later send messages
            to the shared Supabase inbox.
          </p>
        </div>

        <Badge tone={unsafe ? 'gold' : 'green'}>
          {unsafe ? 'Needs edit' : 'Safety ready'}
        </Badge>
      </div>

      <textarea
        value={value}
        onChange={(event) => onChange(event.target.value)}
        placeholder="Example: Hi, I need help with my weekly box order for this weekend."
        className={cn(
          'mt-5 min-h-32 w-full rounded-[24px] border bg-white p-4 text-sm font-semibold leading-6 text-[#183B28] outline-none transition placeholder:text-[#5F6A62]/60 focus:ring-4',
          unsafe
            ? 'border-[#DFA75A] focus:ring-[#DFA75A]/15'
            : 'border-[#D8E5D4] focus:border-[#2D6741]/50 focus:ring-[#2D6741]/10',
        )}
      />

      <div className="mt-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <p className={cn('text-sm font-bold', unsafe ? 'text-[#8B5D18]' : 'text-[#5F6A62]')}>
          {unsafe
            ? 'Remove phone numbers, emails, links, social handles, and direct-contact phrases.'
            : 'Messages should stay inside The Harvest Place Ja.'}
        </p>

        <Button onClick={onSubmit}>Check Message</Button>
      </div>

      {message ? (
        <p
          className={cn(
            'mt-4 rounded-2xl px-4 py-3 text-sm font-black',
            message.includes('remove') || message.includes('safety')
              ? 'bg-[#FFF3D9] text-[#8B5D18]'
              : 'bg-[#EAF5E7] text-[#2D6741]',
          )}
        >
          {message}
        </p>
      ) : null}
    </Card>
  );
}

function SupportCard() {
  return (
    <Card className="border-[#D8E5D4] bg-white p-6 shadow-[0_18px_55px_rgba(24,59,40,0.07)]">
      <h2 className="font-black text-[#183B28]">Support & Help</h2>

      <p className="mt-1 text-sm font-semibold text-[#5F6A62]">
        Need help with orders, delivery, pickup, weekly boxes, or account access?
      </p>

      <div className="mt-4 grid gap-2">
        <SupportRow
          icon={<Headphones className="h-5 w-5" />}
          title="Message support"
          copy="Use the live chat widget for quick help."
        />

        <SupportRow
          icon={<PackageCheck className="h-5 w-5" />}
          title="Order support"
          copy="Track order questions from the same customer account."
        />

        <SupportRow
          icon={<ShieldCheck className="h-5 w-5" />}
          title="Trust & safety"
          copy="Keep customer communication inside the platform."
        />
      </div>

      <Button href="/support" variant="secondary" className="mt-5 w-full border-[#D8E5D4]">
        Open Support Page
      </Button>
    </Card>
  );
}

function ProfileSettingsCard({
  name,
  privateContact,
  address,
  message,
  saving,
  onName,
  onPrivateContact,
  onAddress,
  onSave,
}: {
  name: string;
  privateContact: string;
  address: string;
  message: string;
  saving: boolean;
  onName: (value: string) => void;
  onPrivateContact: (value: string) => void;
  onAddress: (value: string) => void;
  onSave: () => Promise<void>;
}) {
  return (
    <Card className="border-[#D8E5D4] bg-white p-6 shadow-[0_18px_55px_rgba(24,59,40,0.07)]">
      <div className="mb-5 flex items-start gap-4">
        <div className="grid h-12 w-12 place-items-center rounded-full bg-[#EAF5E7] text-[#2D6741]">
          <UserRound className="h-6 w-6" />
        </div>

        <div>
          <h2 className="font-black text-[#183B28]">Profile Settings</h2>
          <p className="mt-1 text-sm font-semibold text-[#5F6A62]">
            Keep your customer details updated and private.
          </p>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Field label="Full name" value={name} onChange={onName} />

        <Field
          label="Private phone number"
          value={privateContact}
          onChange={onPrivateContact}
          placeholder="Only used for order support"
        />

        <label className="grid gap-2 text-sm font-black text-[#183B28] md:col-span-2">
          Delivery parish / area
          <textarea
            value={address}
            onChange={(event) => onAddress(event.target.value)}
            placeholder="Example: Kingston, Portmore, Mandeville, Montego Bay..."
            className="min-h-24 rounded-2xl border border-[#D8E5D4] bg-white p-3 font-bold outline-none transition focus:border-[#2D6741]/50 focus:ring-4 focus:ring-[#2D6741]/10"
          />
        </label>
      </div>

      {message ? <p className="mt-4 text-sm font-bold text-[#2D6741]">{message}</p> : null}

      <Button onClick={onSave} className="mt-5">
        {saving ? 'Saving...' : 'Save Profile'}
      </Button>
    </Card>
  );
}

function AccessCard({
  email,
  isAdmin,
  farmerStatus,
  subscriptionsLabel,
  points,
}: {
  email?: string;
  isAdmin: boolean;
  farmerStatus?: string | null;
  subscriptionsLabel: string;
  points: number;
}) {
  return (
    <Card className="border-[#D8E5D4] bg-white p-6 shadow-[0_18px_55px_rgba(24,59,40,0.07)]">
      <h2 className="font-black text-[#183B28]">Account Access</h2>

      <div className="mt-4 grid gap-3 text-sm font-bold text-[#5F6A62]">
        <InfoRow label="Email" value={email || 'Not set'} />
        <InfoRow label="Admin" value={isAdmin ? 'Approved' : 'No admin access'} />
        <InfoRow label="Farmer profile" value={farmerStatus || 'No profile'} />
        <InfoRow label="Fresh alerts" value={subscriptionsLabel} />
        <InfoRow label="Rewards" value={`${points.toLocaleString()} points`} />
      </div>

      {isAdmin ? (
        <Button href="/admin" className="mt-5 w-full">
          Open Admin Dashboard
        </Button>
      ) : null}
    </Card>
  );
}

function Field({
  label,
  value,
  onChange,
  placeholder,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
}) {
  return (
    <label className="grid gap-2 text-sm font-black text-[#183B28]">
      {label}
      <input
        value={value}
        onChange={(event) => onChange(event.target.value)}
        placeholder={placeholder}
        className="rounded-2xl border border-[#D8E5D4] bg-white p-3 font-bold outline-none transition placeholder:text-[#5F6A62]/50 focus:border-[#2D6741]/50 focus:ring-4 focus:ring-[#2D6741]/10"
      />
    </label>
  );
}

function MiniStat({ value, label }: { value: number; label: string }) {
  return (
    <div className="rounded-2xl border border-[#D8E5D4] bg-[#F4F9F2] px-3 py-3">
      <p className="text-lg font-black text-[#183B28]">{value.toLocaleString()}</p>
      <p className="mt-1 text-[10px] font-black uppercase tracking-[0.12em] text-[#5F6A62]">
        {label}
      </p>
    </div>
  );
}

function SupportRow({ icon, title, copy }: { icon: ReactNode; title: string; copy: string }) {
  return (
    <div className="flex items-center justify-between gap-3 rounded-2xl p-3 text-left transition hover:bg-[#EAF5E7]">
      <span className="grid h-10 w-10 place-items-center rounded-full bg-[#EAF5E7] text-[#2D6741]">
        {icon}
      </span>

      <span className="min-w-0 flex-1">
        <span className="block text-sm font-black text-[#183B28]">{title}</span>
        <span className="block text-xs font-semibold text-[#5F6A62]">{copy}</span>
      </span>

      <ChevronRight className="h-4 w-4 text-[#5F6A62]" />
    </div>
  );
}

function TrustLine({ icon, title, copy }: { icon: ReactNode; title: string; copy: string }) {
  return (
    <div className="flex gap-3">
      <span className="text-[#2D6741]">{icon}</span>

      <span>
        <span className="block text-sm font-black text-[#183B28]">{title}</span>
        <span className="block text-xs font-semibold leading-5 text-[#5F6A62]">{copy}</span>
      </span>
    </div>
  );
}

function InfoRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between gap-4 rounded-2xl border border-[#D8E5D4] bg-white px-4 py-3">
      <span>{label}</span>
      <span className="text-right font-black text-[#183B28]">{value}</span>
    </div>
  );
}
