The Harvest Place Ja - Account Page Fix

What this zip contains:
- src/app/account/page.tsx

What was fixed:
- Sidebar buttons are now functional links.
- Overview, Orders, Fresh Alerts, Delivery, Rewards, Support, and Profile Settings scroll to real sections.
- My Box opens /my-box.
- Admin Dashboard appears only for admins.
- Sign out remains functional.
- The old non-functional "Farm Discovery Account" buttons were replaced by a cleaner "My Account" sidebar.
- The account page wording now matches the marketplace flow: shop, My Box, orders, fresh alerts, delivery, support, rewards, profile.
- Fake fallback farm names were removed.
- External Unsplash fallback images were removed.
- A private phone field was added to profile settings.
- Recent orders no longer show unrelated product thumbnails.

How to install:
1. Extract this zip into your project root:
   C:\Projects\harvest-place-ja-web\harvest-place-ja-web

2. It should replace:
   src\app\account\page.tsx

3. Run:
   npm run build

4. If the build passes:
   git status
   git add -A
   git commit -m "Fix account dashboard navigation"
   git push

Important:
- This file uses SIGN_IN_HREF = '/auth?redirect=/account'.
- If your project does not have src/app/auth/page.tsx, change SIGN_IN_HREF in page.tsx to your real sign-in route.
