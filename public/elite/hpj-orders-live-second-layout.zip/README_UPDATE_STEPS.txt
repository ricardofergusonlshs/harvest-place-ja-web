# HPJ Orders Live Layout Update

This update makes /orders look like the second screenshot:
- Dark green live hero
- Active / Ready / Total order cards
- Large rounded order status cards
- Pending / Preparing / Ready / Delivered progress row
- Refresh every 4 seconds from Supabase orders

Install:
1. Extract into your project root:
   C:\Projects\harvest-place-ja-web\harvest-place-ja-web

2. Replace:
   src/app/orders/page.tsx

3. Run:
   npm run build

4. Restart:
   npm run dev

5. Open:
   http://localhost:3000/orders

Important:
This is for /orders only. Your /my-box page should stay as the Amazon-style cart.
