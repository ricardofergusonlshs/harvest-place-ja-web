'use client';

import { useCallback, useEffect, useMemo, useState, type ReactNode } from 'react';
import {
  Bell,
  CheckCircle2,
  Clock,
  Headphones,
  PackageCheck,
  RefreshCcw,
  ShoppingBag,
  Truck,
  UserRound,
} from 'lucide-react';

import { Badge, Button, Card, EmptyState, LoadingState, StatusChip, cn } from '@/components/ui';
import { useAuth } from '@/components/providers/auth-provider';
import { fetchOrderDetails, fetchOrders } from '@/lib/services';
import { getSupabaseBrowserClient } from '@/lib/supabase/client';
import { formatDate, formatJmd, shortIdLabel } from '@/lib/format';
import type { FarmOrder } from '@/lib/types';

type OrderItemRow = {
  id?: string | number | null;
  order_id?: string | null;
  product_id?: string | null;
  product_name?: string | null;
  name?: string | null;
  quantity?: number | string | null;
  unit_price?: number | string | null;
  line_total?: number | string | null;
};

type LiveOrder = FarmOrder & {
  order_items?: OrderItemRow[] | null;
  items?: OrderItemRow[] | null;
  delivery_status?: string | null;
  order_status?: string | null;
  status?: string | null;
  fulfillment_type?: string | null;
  delivery_method?: string | null;
  subtotal?: number | null;
  delivery_fee?: number | null;
  total?: number | null;
};

const READY_STATUSES = new Set(['ready', 'ready_for_pickup', 'out_for_delivery']);
const CLOSED_STATUSES = new Set(['delivered', 'completed', 'cancelled', 'canceled', 'rejected']);

export default function MyBoxPage() {
  const { user, loading: authLoading } = useAuth();

  const [orders, setOrders] = useState<LiveOrder[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);
  const [errorMessage, setErrorMessage] = useState('');

  const loadOrders = useCallback(async (showRefreshing = false) => {
    if (!user) {
      setOrders([]);
      setLoading(false);
      return;
    }

    if (showRefreshing) setRefreshing(true);
    setErrorMessage('');

    try {
      const baseOrders = await fetchOrders();

      const detailedOrders = await Promise.all(
        baseOrders.slice(0, 12).map(async (order) => {
          try {
            const detail = await fetchOrderDetails(String(order.id));
            return (detail || order) as LiveOrder;
          } catch {
            return order as LiveOrder;
          }
        }),
      );

      setOrders(detailedOrders);
      setLastUpdated(new Date());
    } catch (error) {
      console.error('Live My Box failed to load:', error);
      setErrorMessage(
        error instanceof Error
          ? error.message
          : 'My Box could not load from Supabase right now.',
      );
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [user]);

  useEffect(() => {
    if (authLoading) return;
    void loadOrders(false);
  }, [authLoading, loadOrders]);

  useEffect(() => {
    if (!user) return;

    const supabase = getSupabaseBrowserClient();

    const channel = supabase
      .channel(`website-my-box-live-${user.id}`)
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'orders' },
        () => {
          void loadOrders(false);
        },
      )
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'order_items' },
        () => {
          void loadOrders(false);
        },
      )
      .subscribe();

    return () => {
      void supabase.removeChannel(channel);
    };
  }, [loadOrders, user]);

  const activeOrders = useMemo(
    () => orders.filter((order) => !CLOSED_STATUSES.has(normalizeStatus(getOrderStatus(order)))),
    [orders],
  );

  const completedOrders = useMemo(
    () => orders.filter((order) => CLOSED_STATUSES.has(normalizeStatus(getOrderStatus(order)))),
    [orders],
  );

  const readyOrders = useMemo(
    () => orders.filter((order) => READY_STATUSES.has(normalizeStatus(getOrderStatus(order)))),
    [orders],
  );

  const activeItemCount = useMemo(
    () =>
      activeOrders.reduce((sum, order) => {
        const items = getOrderItems(order);
        if (!items.length) return sum;
        return sum + items.reduce((itemSum, item) => itemSum + Number(item.quantity || 0), 0);
      }, 0),
    [activeOrders],
  );

  if (authLoading || loading) {
    return (
      <main className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
        <LoadingState />
      </main>
    );
  }

  if (!user) {
    return (
      <main className="min-h-screen bg-[linear-gradient(180deg,#FAF8F0_0%,#F4F9F2_52%,#FFFEFC_100%)] px-4 py-10 text-[#183B28] sm:px-6 lg:px-10">
        <section className="mx-auto max-w-5xl">
          <EmptyState
            title="Sign in to view your box"
            subtitle="Your phone app and website can only show the same My Box when you are signed in with the same account."
            action={
              <div className="flex flex-wrap justify-center gap-3">
                <Button href="/account?mode=signin">Sign in</Button>
                <Button href="/shop" variant="secondary">
                  Shop Produce
                </Button>
              </div>
            }
          />
        </section>
      </main>
    );
  }

  return (
    <main className="min-h-screen bg-[linear-gradient(180deg,#FAF8F0_0%,#F4F9F2_52%,#FFFEFC_100%)] text-[#183B28]">
      <section className="mx-auto max-w-[1450px] px-4 py-8 sm:px-6 lg:px-10">
        <LiveBoxHero
          activeOrders={activeOrders.length}
          readyOrders={readyOrders.length}
          activeItemCount={activeItemCount}
          lastUpdated={lastUpdated}
          refreshing={refreshing}
          onRefresh={() => loadOrders(true)}
        />

        {errorMessage ? (
          <div className="mt-5 rounded-3xl border border-red-200 bg-red-50 px-5 py-4 text-sm font-bold text-red-700">
            {errorMessage}
          </div>
        ) : null}

        <div className="mt-8 grid gap-6 lg:grid-cols-[1fr_380px]">
          <section className="grid gap-5">
            <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
              <div>
                <p className="text-xs font-black uppercase tracking-[0.18em] text-[#DFA75A]">
                  Shared Supabase box
                </p>
                <h1 className="text-2xl font-black tracking-tight text-[#183B28] sm:text-3xl">
                  Live order and item status
                </h1>
                <p className="mt-2 max-w-2xl text-sm font-semibold leading-6 text-[#5F6A62]">
                  This page now reads from the same Supabase orders and order_items tables used by the app. When an order is marked ready in Supabase, this page updates live.
                </p>
              </div>

              <Button href="/shop" variant="secondary">
                <ShoppingBag className="h-4 w-4" />
                Shop More
              </Button>
            </div>

            {activeOrders.length ? (
              <div className="grid gap-5">
                {activeOrders.map((order) => (
                  <LiveOrderCard key={String(order.id)} order={order} />
                ))}
              </div>
            ) : (
              <EmptyLiveBox />
            )}

            {completedOrders.length ? (
              <section className="mt-4">
                <h2 className="mb-3 text-xl font-black text-[#183B28]">
                  Recent completed orders
                </h2>
                <div className="grid gap-3">
                  {completedOrders.slice(0, 4).map((order) => (
                    <CompactOrderRow key={String(order.id)} order={order} />
                  ))}
                </div>
              </section>
            ) : null}
          </section>

          <aside className="space-y-5">
            <LiveStatusPanel
              activeOrders={activeOrders.length}
              readyOrders={readyOrders.length}
              completedOrders={completedOrders.length}
              activeItemCount={activeItemCount}
              lastUpdated={lastUpdated}
              refreshing={refreshing}
              onRefresh={() => loadOrders(true)}
            />

            <Card className="rounded-[28px] border border-[#D8E5D4] bg-white p-5 shadow-[0_18px_50px_rgba(24,59,40,0.06)]">
              <div className="grid gap-3 text-sm font-bold text-[#5F6A62]">
                <TrustLine
                  icon={<CheckCircle2 className="h-4 w-4" />}
                  title="Phone app and website use Supabase"
                />
                <TrustLine
                  icon={<PackageCheck className="h-4 w-4" />}
                  title="Ready status comes from orders.order_status"
                />
                <TrustLine
                  icon={<Truck className="h-4 w-4" />}
                  title="Pickup and delivery status update live"
                />
                <TrustLine
                  icon={<Headphones className="h-4 w-4" />}
                  title="Support can see the same order history"
                />
              </div>
            </Card>
          </aside>
        </div>
      </section>
    </main>
  );
}

function LiveBoxHero({
  activeOrders,
  readyOrders,
  activeItemCount,
  lastUpdated,
  refreshing,
  onRefresh,
}: {
  activeOrders: number;
  readyOrders: number;
  activeItemCount: number;
  lastUpdated: Date | null;
  refreshing: boolean;
  onRefresh: () => void;
}) {
  return (
    <section className="relative overflow-hidden rounded-[34px] bg-[#183B28] px-6 py-7 text-white shadow-[0_30px_90px_rgba(24,59,40,0.22)] sm:px-8 lg:px-10">
      <div className="absolute right-[-100px] top-[-120px] h-72 w-72 rounded-full bg-[#2D6741] opacity-70 blur-3xl" />
      <div className="absolute bottom-[-120px] left-[-100px] h-72 w-72 rounded-full bg-[#DFA75A] opacity-25 blur-3xl" />

      <div className="relative z-10 grid gap-6 lg:grid-cols-[1fr_auto] lg:items-center">
        <div>
          <Badge tone="gold">
            <Bell className="h-3 w-3" />
            Live from Supabase
          </Badge>

          <h1 className="mt-4 max-w-3xl text-4xl font-black leading-[0.96] tracking-[-0.055em] sm:text-5xl">
            My Box is now live.
          </h1>

          <p className="mt-4 max-w-2xl text-sm font-semibold leading-7 text-white/80 sm:text-base">
            Your website box now shows the same active orders and ready statuses coming from Supabase.
          </p>

          <p className="mt-3 text-xs font-bold text-white/65">
            {lastUpdated ? `Last updated ${lastUpdated.toLocaleTimeString()}` : 'Waiting for first update'}
          </p>
        </div>

        <div className="grid gap-3 sm:grid-cols-3 lg:min-w-[430px]">
          <HeroStat label="Active orders" value={activeOrders} />
          <HeroStat label="Ready" value={readyOrders} />
          <HeroStat label="Items" value={activeItemCount} />
        </div>

        <button
          type="button"
          onClick={onRefresh}
          disabled={refreshing}
          className="inline-flex w-fit items-center justify-center gap-2 rounded-full bg-white px-5 py-3 text-sm font-black text-[#183B28] shadow-lg transition hover:bg-[#EAF5E7] disabled:cursor-not-allowed disabled:opacity-60"
        >
          <RefreshCcw className={cn('h-4 w-4', refreshing && 'animate-spin')} />
          Refresh now
        </button>
      </div>
    </section>
  );
}

function HeroStat({ label, value }: { label: string; value: number }) {
  return (
    <div className="rounded-3xl border border-white/12 bg-white/10 p-5 text-center backdrop-blur">
      <p className="text-xs font-black uppercase tracking-[0.18em] text-[#DFA75A]">
        {label}
      </p>
      <p className="mt-2 text-4xl font-black">{value}</p>
    </div>
  );
}

function EmptyLiveBox() {
  return (
    <Card className="rounded-[30px] border border-dashed border-[#D8E5D4] bg-white p-10 text-center shadow-[0_18px_50px_rgba(24,59,40,0.06)]">
      <div className="mx-auto grid h-16 w-16 place-items-center rounded-full bg-[#EAF5E7] text-[#2D6741]">
        <ShoppingBag className="h-8 w-8" />
      </div>
      <h2 className="mt-5 text-2xl font-black text-[#183B28]">No active box yet</h2>
      <p className="mx-auto mt-2 max-w-xl text-sm font-semibold leading-6 text-[#5F6A62]">
        You do not have a pending, preparing, ready, or pickup order on this account. Start shopping or sign in with the same account used on the phone app.
      </p>
      <div className="mt-6 flex flex-wrap justify-center gap-3">
        <Button href="/shop">Shop This Week’s Harvest</Button>
        <Button href="/orders" variant="secondary">
          View Orders
        </Button>
      </div>
    </Card>
  );
}

function LiveOrderCard({ order }: { order: LiveOrder }) {
  const status = getOrderStatus(order);
  const normalizedStatus = normalizeStatus(status);
  const ready = READY_STATUSES.has(normalizedStatus);
  const items = getOrderItems(order);
  const subtotal = Number(order.subtotal || 0);
  const deliveryFee = Number(order.delivery_fee || 0);
  const total = Number(order.total ?? subtotal + deliveryFee);

  return (
    <Card className={cn(
      'rounded-[30px] border bg-white p-5 shadow-[0_18px_50px_rgba(24,59,40,0.06)]',
      ready ? 'border-[#2D6741]/40 ring-4 ring-[#2D6741]/10' : 'border-[#D8E5D4]',
    )}>
      <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
        <div>
          <div className="flex flex-wrap items-center gap-2">
            <h2 className="text-xl font-black text-[#183B28]">
              Order #HPJ-{shortIdLabel(String(order.id))}
            </h2>
            <StatusChip status={status} />
            {ready ? (
              <span className="inline-flex items-center gap-1 rounded-full bg-[#EAF5E7] px-3 py-1 text-xs font-black text-[#2D6741]">
                <CheckCircle2 className="h-3.5 w-3.5" />
                Ready update live
              </span>
            ) : null}
          </div>

          <p className="mt-2 text-xs font-bold text-[#5F6A62]">
            {formatDate(String(order.created_at || ''))} • {getFulfillmentLabel(order)}
          </p>
        </div>

        <div className="rounded-3xl border border-[#D8E5D4] bg-[#F4F9F2] px-5 py-3 text-right">
          <p className="text-xs font-black uppercase tracking-[0.16em] text-[#5F6A62]">
            Total
          </p>
          <p className="mt-1 text-xl font-black text-[#183B28]">
            {formatJmd(total)}
          </p>
        </div>
      </div>

      <OrderStatusSteps status={status} />

      <div className="mt-5">
        <h3 className="mb-3 text-sm font-black uppercase tracking-[0.16em] text-[#183B28]">
          Items in this box
        </h3>

        {items.length ? (
          <div className="grid gap-3">
            {items.map((item, index) => (
              <OrderItemLine key={String(item.id ?? `${order.id}-${index}`)} item={item} />
            ))}
          </div>
        ) : (
          <div className="rounded-2xl border border-dashed border-[#D8E5D4] bg-[#F4F9F2] p-4 text-sm font-semibold text-[#5F6A62]">
            Items are attached to this order, but order_items are not readable yet. Check RLS SELECT policy on order_items.
          </div>
        )}
      </div>

      <div className="mt-5 flex flex-wrap gap-3">
        <Button href={`/orders/${order.id}`}>
          View Full Order
        </Button>
        <Button href="/support" variant="secondary">
          Get Help
        </Button>
      </div>
    </Card>
  );
}

function CompactOrderRow({ order }: { order: LiveOrder }) {
  const status = getOrderStatus(order);
  const subtotal = Number(order.subtotal || 0);
  const deliveryFee = Number(order.delivery_fee || 0);
  const total = Number(order.total ?? subtotal + deliveryFee);

  return (
    <a
      href={`/orders/${order.id}`}
      className="block rounded-3xl border border-[#D8E5D4] bg-white p-4 shadow-sm transition hover:border-[#2D6741]/35 hover:bg-[#EAF5E7]"
    >
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <div className="flex flex-wrap items-center gap-2">
            <p className="font-black text-[#183B28]">
              Order #HPJ-{shortIdLabel(String(order.id))}
            </p>
            <StatusChip status={status} />
          </div>
          <p className="mt-1 text-xs font-bold text-[#5F6A62]">
            {formatDate(String(order.created_at || ''))} • {getFulfillmentLabel(order)}
          </p>
        </div>
        <p className="text-sm font-black text-[#183B28]">{formatJmd(total)}</p>
      </div>
    </a>
  );
}

function OrderItemLine({ item }: { item: OrderItemRow }) {
  const quantity = Number(item.quantity || 0);
  const unitPrice = Number(item.unit_price || 0);
  const lineTotal = Number(item.line_total ?? unitPrice * quantity);
  const name = item.product_name || item.name || 'Fresh produce item';

  return (
    <div className="flex flex-col gap-3 rounded-2xl border border-[#D8E5D4] bg-[#FFFEFC] p-4 sm:flex-row sm:items-center sm:justify-between">
      <div>
        <p className="font-black text-[#183B28]">{name}</p>
        <p className="mt-1 text-xs font-bold text-[#5F6A62]">
          Quantity {quantity || 1}
          {unitPrice ? ` • ${formatJmd(unitPrice)} each` : ''}
        </p>
      </div>

      <p className="font-black text-[#183B28]">
        {lineTotal ? formatJmd(lineTotal) : 'Price pending'}
      </p>
    </div>
  );
}

function OrderStatusSteps({ status }: { status: string }) {
  const normalized = normalizeStatus(status);
  const steps = [
    { key: 'pending', label: 'Placed', Icon: Clock },
    { key: 'preparing', label: 'Preparing', Icon: PackageCheck },
    { key: 'ready', label: 'Ready', Icon: CheckCircle2 },
    { key: 'delivered', label: 'Completed', Icon: Truck },
  ];

  const activeIndex = getStatusIndex(normalized);

  return (
    <div className="mt-5 grid grid-cols-4 gap-2">
      {steps.map(({ key, label, Icon }, index) => {
        const active = index <= activeIndex;

        return (
          <div key={key} className="text-center">
            <div
              className={cn(
                'mx-auto grid h-9 w-9 place-items-center rounded-full border text-[11px] font-black',
                active
                  ? 'border-[#2D6741] bg-[#2D6741] text-white'
                  : 'border-[#D8E5D4] bg-white text-[#5F6A62]',
              )}
            >
              <Icon className="h-4 w-4" />
            </div>
            <p className={cn(
              'mt-2 text-[10px] font-black uppercase tracking-[0.08em]',
              active ? 'text-[#183B28]' : 'text-[#5F6A62]',
            )}>
              {label}
            </p>
          </div>
        );
      })}
    </div>
  );
}

function LiveStatusPanel({
  activeOrders,
  readyOrders,
  completedOrders,
  activeItemCount,
  lastUpdated,
  refreshing,
  onRefresh,
}: {
  activeOrders: number;
  readyOrders: number;
  completedOrders: number;
  activeItemCount: number;
  lastUpdated: Date | null;
  refreshing: boolean;
  onRefresh: () => void;
}) {
  return (
    <Card className="sticky top-32 h-fit rounded-[30px] border border-[#D8E5D4] bg-white p-6 shadow-[0_24px_70px_rgba(24,59,40,0.10)]">
      <Badge tone="green">
        <Bell className="h-3 w-3" />
        Live status
      </Badge>

      <h2 className="mt-4 text-2xl font-black tracking-[-0.035em] text-[#183B28]">
        Box summary
      </h2>

      <div className="mt-5 grid gap-3 text-sm font-bold text-[#5F6A62]">
        <SummaryRow label="Active orders" value={activeOrders} />
        <SummaryRow label="Ready now" value={readyOrders} />
        <SummaryRow label="Active items" value={activeItemCount} />
        <SummaryRow label="Completed shown" value={completedOrders} />
      </div>

      <p className="mt-5 rounded-3xl border border-[#D8E5D4] bg-[#F4F9F2] p-4 text-xs font-bold leading-5 text-[#5F6A62]">
        {lastUpdated ? `Last updated ${lastUpdated.toLocaleTimeString()}.` : 'Waiting for updates.'}
        {' '}If Supabase Realtime is enabled for orders and order_items, this page refreshes automatically when status changes.
      </p>

      <button
        type="button"
        onClick={onRefresh}
        disabled={refreshing}
        className="mt-5 inline-flex w-full items-center justify-center gap-2 rounded-full bg-[#183B28] px-5 py-3 text-sm font-black text-white shadow-lg transition hover:bg-[#2D6741] disabled:cursor-not-allowed disabled:opacity-60"
      >
        <RefreshCcw className={cn('h-4 w-4', refreshing && 'animate-spin')} />
        Refresh status
      </button>
    </Card>
  );
}

function SummaryRow({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="flex justify-between rounded-2xl bg-[#F4F9F2] px-4 py-3">
      <span>{label}</span>
      <span className="font-black text-[#183B28]">{value}</span>
    </div>
  );
}

function TrustLine({
  icon,
  title,
}: {
  icon: ReactNode;
  title: string;
}) {
  return (
    <div className="flex items-center gap-3">
      <span className="grid h-9 w-9 place-items-center rounded-full bg-[#EAF5E7] text-[#2D6741]">
        {icon}
      </span>
      <span>{title}</span>
    </div>
  );
}

function getOrderStatus(order: LiveOrder) {
  return String(order.order_status || order.delivery_status || order.status || 'pending');
}

function normalizeStatus(status: string) {
  return status.trim().toLowerCase().replace(/\s+/g, '_');
}

function getStatusIndex(status: string) {
  if (status.includes('delivered') || status.includes('complete')) return 3;
  if (status.includes('ready') || status.includes('pickup') || status.includes('out_for_delivery')) return 2;
  if (status.includes('prepar') || status.includes('pack') || status.includes('review')) return 1;
  return 0;
}

function getFulfillmentLabel(order: LiveOrder) {
  const raw = String(order.fulfillment_type || order.delivery_method || 'pickup');
  return raw
    .replace(/_/g, ' ')
    .replace(/\b\w/g, (letter) => letter.toUpperCase());
}

function getOrderItems(order: LiveOrder) {
  const fromOrderItems = Array.isArray(order.order_items) ? order.order_items : [];
  const fromItems = Array.isArray(order.items) ? order.items : [];

  return fromOrderItems.length ? fromOrderItems : fromItems;
}
