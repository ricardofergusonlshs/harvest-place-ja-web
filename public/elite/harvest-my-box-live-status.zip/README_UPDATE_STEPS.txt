# Harvest Place Ja - Live My Box Status Update

This replaces `src/app/my-box/page.tsx`.

## What it fixes

The old website My Box was browser-only. It used the local cart provider and localStorage, so it could not show the same My Box/order state as the Android app.

This new page reads from Supabase:

- `orders`
- `order_items`

It shows:

- active customer orders
- ready / ready_for_pickup status
- item lines from order_items
- completed recent orders
- live updates when Supabase Realtime is enabled

## Install

Copy this folder into your project root so it replaces:

src/app/my-box/page.tsx

Then run:

npm run build

Then:

npm run dev

## Supabase Realtime

In Supabase, enable Realtime for:

- orders
- order_items

You can do this in Supabase dashboard under Database > Replication / Realtime.

If Realtime is not enabled, the page still works with the Refresh status button.
