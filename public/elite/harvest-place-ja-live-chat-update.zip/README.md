# The Harvest Place Ja - Live Chat Update

This update adds a customer-to-admin live chat using Supabase tables, RLS, and Realtime.

## Files included

```text
supabase/live-chat.sql
src/lib/live-chat.ts
src/components/chat/live-chat-widget.tsx
src/app/admin/chat/page.tsx
```

## Step 1: Run the SQL

Open Supabase → SQL Editor and run:

```text
supabase/live-chat.sql
```

This creates:

```text
support_chat_threads
support_chat_messages
public.is_hpj_admin()
RLS policies
Realtime publication entries
```

## Step 2: Copy the files into your project

Copy these files into the matching folders:

```text
src/lib/live-chat.ts
src/components/chat/live-chat-widget.tsx
src/app/admin/chat/page.tsx
```

## Step 3: Add the floating live chat widget to SiteShell

Open:

```text
src/components/shell/site-shell.tsx
```

Add this import near the top:

```tsx
import LiveChatWidget from '@/components/chat/live-chat-widget';
```

Then inside `SiteShell`, place this near the bottom, before `</div>` of the main wrapper. A safe place is just before `<MobileBottomNav ... />` or just before `<MarketplaceFooter />`:

```tsx
<LiveChatWidget />
```

Example:

```tsx
<main id="main-content" className="w-full">
  {children}
</main>

<LiveChatWidget />
<MobileBottomNav count={count} pathname={pathname} />
<MarketplaceFooter />
```

## Step 4: Admin inbox

After copying the files, admins can open:

```text
/admin/chat
```

Customers can use the floating chat button on the website after signing in.

## Step 5: Build and deploy

```powershell
npm run build
npm run dev
```

Then commit and push:

```powershell
git add .
git commit -m "Add live chat support"
git push
```

## Notes

- This does not change existing Supabase product/order/cart/auth logic.
- This adds two new Supabase tables because live chat needs somewhere to store messages.
- RLS restricts customers to their own conversations and allows admins to see all chats.
- The admin checker supports common `admin_users` columns: `user_id`, `id`, or `email`.
