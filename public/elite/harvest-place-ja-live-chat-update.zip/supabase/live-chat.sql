-- The Harvest Place Ja: Customer ↔ Admin live chat
-- Run this once in Supabase SQL Editor.
-- It creates chat tables, RLS policies, indexes, and enables Realtime for chat.

create extension if not exists pgcrypto;

-- Flexible admin checker for projects where admin_users may use user_id, id, or email.
create or replace function public.is_hpj_admin()
returns boolean
language plpgsql
security definer
set search_path = public, auth
as $$
declare
  v_uid uuid := auth.uid();
  v_email text := coalesce(auth.jwt() ->> 'email', '');
  v_exists boolean := false;
begin
  if v_uid is null then
    return false;
  end if;

  -- JWT role fallback, useful if you later add app_metadata.role = 'admin'
  if coalesce(auth.jwt() -> 'app_metadata' ->> 'role', '') = 'admin' then
    return true;
  end if;

  if to_regclass('public.admin_users') is null then
    return false;
  end if;

  if exists (
    select 1 from information_schema.columns
    where table_schema = 'public' and table_name = 'admin_users' and column_name = 'user_id'
  ) then
    execute 'select exists(select 1 from public.admin_users where user_id = $1)'
    using v_uid into v_exists;
    if v_exists then return true; end if;
  end if;

  if exists (
    select 1 from information_schema.columns
    where table_schema = 'public' and table_name = 'admin_users' and column_name = 'id'
  ) then
    execute 'select exists(select 1 from public.admin_users where id = $1)'
    using v_uid into v_exists;
    if v_exists then return true; end if;
  end if;

  if v_email <> '' and exists (
    select 1 from information_schema.columns
    where table_schema = 'public' and table_name = 'admin_users' and column_name = 'email'
  ) then
    execute 'select exists(select 1 from public.admin_users where lower(email) = lower($1))'
    using v_email into v_exists;
    if v_exists then return true; end if;
  end if;

  return false;
end;
$$;

create table if not exists public.support_chat_threads (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid not null references auth.users(id) on delete cascade,
  customer_email text,
  customer_name text,
  subject text not null default 'Customer support chat',
  status text not null default 'open' check (status in ('open', 'waiting', 'resolved', 'closed')),
  last_message text,
  last_message_at timestamptz not null default now(),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.support_chat_messages (
  id uuid primary key default gen_random_uuid(),
  thread_id uuid not null references public.support_chat_threads(id) on delete cascade,
  sender_id uuid not null references auth.users(id) on delete cascade,
  sender_role text not null check (sender_role in ('customer', 'admin')),
  body text not null check (char_length(trim(body)) between 1 and 1500),
  is_read boolean not null default false,
  created_at timestamptz not null default now()
);

create index if not exists idx_support_chat_threads_customer_id
  on public.support_chat_threads(customer_id);

create index if not exists idx_support_chat_threads_status_last_message
  on public.support_chat_threads(status, last_message_at desc);

create index if not exists idx_support_chat_messages_thread_created
  on public.support_chat_messages(thread_id, created_at asc);

create or replace function public.touch_support_chat_thread()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  update public.support_chat_threads
  set
    last_message = new.body,
    last_message_at = new.created_at,
    updated_at = now(),
    status = case
      when new.sender_role = 'customer' and status = 'resolved' then 'open'
      else status
    end
  where id = new.thread_id;

  return new;
end;
$$;

drop trigger if exists trg_touch_support_chat_thread on public.support_chat_messages;
create trigger trg_touch_support_chat_thread
after insert on public.support_chat_messages
for each row execute function public.touch_support_chat_thread();

alter table public.support_chat_threads enable row level security;
alter table public.support_chat_messages enable row level security;

-- Thread policies
create policy "Customers can view their own chat threads"
on public.support_chat_threads
for select
to authenticated
using (customer_id = auth.uid() or public.is_hpj_admin());

create policy "Customers can create their own chat threads"
on public.support_chat_threads
for insert
to authenticated
with check (customer_id = auth.uid());

create policy "Customers can update their own open chat threads"
on public.support_chat_threads
for update
to authenticated
using (customer_id = auth.uid() or public.is_hpj_admin())
with check (customer_id = auth.uid() or public.is_hpj_admin());

-- Message policies
create policy "Customers and admins can view messages in allowed threads"
on public.support_chat_messages
for select
to authenticated
using (
  public.is_hpj_admin()
  or exists (
    select 1
    from public.support_chat_threads t
    where t.id = support_chat_messages.thread_id
      and t.customer_id = auth.uid()
  )
);

create policy "Customers can send messages in their own threads"
on public.support_chat_messages
for insert
to authenticated
with check (
  sender_id = auth.uid()
  and sender_role = 'customer'
  and exists (
    select 1
    from public.support_chat_threads t
    where t.id = support_chat_messages.thread_id
      and t.customer_id = auth.uid()
  )
);

create policy "Admins can send admin replies"
on public.support_chat_messages
for insert
to authenticated
with check (
  sender_id = auth.uid()
  and sender_role = 'admin'
  and public.is_hpj_admin()
);

create policy "Customers and admins can mark messages read"
on public.support_chat_messages
for update
to authenticated
using (
  public.is_hpj_admin()
  or exists (
    select 1
    from public.support_chat_threads t
    where t.id = support_chat_messages.thread_id
      and t.customer_id = auth.uid()
  )
)
with check (
  public.is_hpj_admin()
  or exists (
    select 1
    from public.support_chat_threads t
    where t.id = support_chat_messages.thread_id
      and t.customer_id = auth.uid()
  )
);

-- Make sure authenticated users can access the tables through PostgREST in newer Supabase projects.
grant usage on schema public to authenticated;
grant select, insert, update on public.support_chat_threads to authenticated;
grant select, insert, update on public.support_chat_messages to authenticated;

-- Enable Postgres Changes Realtime for these tables.
do $$
begin
  alter publication supabase_realtime add table public.support_chat_threads;
exception when duplicate_object then null;
end $$;

do $$
begin
  alter publication supabase_realtime add table public.support_chat_messages;
exception when duplicate_object then null;
end $$;
