Harvest Place Ja - Super Friendly Account Page Update

What this fixes:
1. Replaces the old sidebar links with real topic buttons.
2. Every sidebar topic scrolls to a real section on the account page.
3. Adds active section highlighting while the user scrolls.
4. Adds a mobile topic bar for phones/tablets.
5. Makes the account page clearer: Overview, My Box, Orders, Fresh Alerts, Delivery Details, Rewards, Support, Settings.
6. Keeps existing Supabase profile, orders, loyalty, products, and fresh alert calls.
7. Keeps sign out working.

How to apply:
1. Extract this zip into your project root:
   C:\Projects\harvest-place-ja-web\harvest-place-ja-web

2. It should replace:
   src\app\account\page.tsx

3. Run:
   npm run build

4. If build passes:
   git status
   git add -A
   git commit -m "Make account dashboard navigation user friendly"
   git push

Important:
If your project does not have src/app/auth/page.tsx, change SIGN_IN_HREF in page.tsx to your real sign-in route.
