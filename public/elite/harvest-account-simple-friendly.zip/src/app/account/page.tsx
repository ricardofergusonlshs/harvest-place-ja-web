'use client';

import Image from 'next/image';
import { useEffect, useMemo, useState, type ReactNode } from 'react';
import {
  Bell,
  ChevronRight,
  Gift,
  Headphones,
  Home,
  LogOut,
  MapPin,
  PackageCheck,
  Pencil,
  ShieldCheck,
  ShoppingBag,
  Sprout,
  Truck,
  UserRound,
} from 'lucide-react';

import { Badge, Button, Card, EmptyState, LoadingState, StatusChip, cn } from '@/components/ui';
import { useAuth } from '@/components/providers/auth-provider';
import {
  fetchCurrentCustomerProfile,
  fetchCustomerProductSubscriptions,
  fetchLoyaltySummary,
  fetchOrders,
  saveCurrentCustomerProfile,
} from '@/lib/services';
import { formatDate, formatJmd, safeEmailName, shortIdLabel } from '@/lib/format';
import type {
  CustomerProfile,
  CustomerProductSubscription,
  FarmOrder,
  LoyaltySummary,
} from '@/lib/types';

const SIGN_IN_HREF = '/auth?redirect=/account';

type DashboardState = {
  profile: CustomerProfile | null;
  loyalty: LoyaltySummary;
  subs: CustomerProductSubscription[];
  orders: FarmOrder[];
};

const emptyDashboard: DashboardState = {
  profile: null,
  loyalty: { points: 0, lifetime_points: 0, tier: 'Seedling' },
  subs: [],
  orders: [],
};

const quickActions = [
  {
    title: 'Shop Produce',
    copy: 'Browse fresh items and add them to your box.',
    href: '/shop',
    Icon: Sprout,
  },
  {
    title: 'My Box',
    copy: 'Review your selected items before checkout.',
    href: '/my-box',
    Icon: ShoppingBag,
  },
  {
    title: 'Orders',
    copy: 'Track order progress, pickup, and delivery.',
    href: '/orders',
    Icon: PackageCheck,
  },
  {
    title: 'Fresh Alerts',
    copy: 'Manage ready-soon notifications.',
    href: '/ready-soon',
    Icon: Bell,
  },
  {
    title: 'Support',
    copy: 'Get help with orders or your account.',
    href: '/support',
    Icon: Headphones,
  },
] as const;

export default function AccountPage() {
  const { user, loading: authLoading, farmerProfile, isAdmin, signOut } = useAuth();

  const [state, setState] = useState<DashboardState>(emptyDashboard);
  const [loading, setLoading] = useState(true);
  const [savingProfile, setSavingProfile] = useState(false);
  const [profileMessage, setProfileMessage] = useState('');

  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');

  useEffect(() => {
    let alive = true;

    async function loadAccount() {
      if (authLoading) return;

      if (!user) {
        setState(emptyDashboard);
        setLoading(false);
        return;
      }

      setLoading(true);

      const [profile, loyalty, subs, orders] = await Promise.all([
        safeResolve(fetchCurrentCustomerProfile(), null),
        safeResolve(
          fetchLoyaltySummary(),
          { points: 0, lifetime_points: 0, tier: 'Seedling' } as LoyaltySummary,
        ),
        safeResolve(fetchCustomerProductSubscriptions(), [] as CustomerProductSubscription[]),
        safeResolve(fetchOrders(), [] as FarmOrder[]),
      ]);

      if (!alive) return;

      setState({ profile, loyalty, subs, orders });
      setName(profile?.full_name || safeEmailName(user.email) || '');
      setPhone(profile?.phone || '');
      setAddress(profile?.address || '');
      setLoading(false);
    }

    loadAccount();

    return () => {
      alive = false;
    };
  }, [user, authLoading]);

  const displayName = useMemo(
    () => name || state.profile?.full_name || safeEmailName(user?.email) || 'Harvest Customer',
    [name, state.profile?.full_name, user?.email],
  );

  const points = Number(state.loyalty.points || 0);
  const lifetimePoints = Number(state.loyalty.lifetime_points || 0);
  const tier = state.loyalty.tier || 'Seedling';
  const recentOrders = state.orders.slice(0, 3);
  const activeAlerts = state.subs.length;

  async function handleSaveProfile() {
    if (savingProfile) return;

    setSavingProfile(true);
    setProfileMessage('Saving your profile...');

    try {
      await saveCurrentCustomerProfile({
        full_name: name || displayName,
        phone,
        address,
      });

      setProfileMessage('Profile saved successfully.');
    } catch (error) {
      setProfileMessage(error instanceof Error ? error.message : 'Profile could not be saved right now.');
    } finally {
      setSavingProfile(false);
    }
  }

  async function handleSignOut() {
    try {
      await signOut();
    } catch (error) {
      console.error('Sign out failed:', error);
    }
  }

  if (authLoading || loading) {
    return (
      <main className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
        <LoadingState />
      </main>
    );
  }

  if (!user) {
    return (
      <main className="min-h-screen bg-[#FAF8F0] px-4 py-12 text-[#183B28] sm:px-6 lg:px-8">
        <div className="mx-auto max-w-4xl">
          <EmptyState
            title="Sign in to manage your account"
            subtitle="View your orders, manage fresh alerts, save your delivery details, and get support from The Harvest Place Ja."
            action={
              <div className="flex flex-wrap justify-center gap-3">
                <Button href={SIGN_IN_HREF}>Sign in</Button>
                <Button href="/shop" variant="secondary">
                  Continue shopping
                </Button>
              </div>
            }
          />
        </div>
      </main>
    );
  }

  return (
    <main className="min-h-screen bg-[#FAF8F0] text-[#183B28]">
      <div className="mx-auto grid max-w-7xl gap-6 px-4 py-8 sm:px-6 lg:px-8">
        <AccountHero
          displayName={displayName}
          email={user.email}
          isAdmin={isAdmin}
          farmerStatus={farmerProfile?.verification_status}
          onSignOut={handleSignOut}
        />

        <QuickActions />

        <section className="grid gap-6 lg:grid-cols-3">
          <SummaryCard
            title="Orders"
            value={state.orders.length.toString()}
            copy="Recent purchases and order tracking"
            href="/orders"
            Icon={PackageCheck}
          />

          <SummaryCard
            title="Fresh Alerts"
            value={activeAlerts.toString()}
            copy="Ready-soon notifications"
            href="/ready-soon"
            Icon={Bell}
          />

          <SummaryCard
            title="Rewards"
            value={points.toLocaleString()}
            copy={`${tier} tier • ${lifetimePoints.toLocaleString()} lifetime points`}
            href="/account"
            Icon={Gift}
          />
        </section>

        <section className="grid gap-6 lg:grid-cols-[1.1fr_0.9fr]">
          <RecentOrders orders={recentOrders} />
          <DeliveryCard address={address} />
        </section>

        <section className="grid gap-6 lg:grid-cols-[1.1fr_0.9fr]">
          <ProfileCard
            name={name}
            phone={phone}
            address={address}
            message={profileMessage}
            saving={savingProfile}
            onName={setName}
            onPhone={setPhone}
            onAddress={setAddress}
            onSave={handleSaveProfile}
          />

          <SupportAndSecurityCard
            isAdmin={isAdmin}
            farmerStatus={farmerProfile?.verification_status}
            email={user.email}
          />
        </section>
      </div>
    </main>
  );
}

async function safeResolve<T>(promise: Promise<T>, fallback: T, timeoutMs = 16000): Promise<T> {
  try {
    return await Promise.race([
      promise,
      new Promise<T>((resolve) => window.setTimeout(() => resolve(fallback), timeoutMs)),
    ]);
  } catch (error) {
    console.error('Account data failed to load:', error);
    return fallback;
  }
}

function getOrderStatus(order: FarmOrder) {
  const item = order as FarmOrder & {
    delivery_status?: string | null;
    order_status?: string | null;
    status?: string | null;
  };

  return item.delivery_status || item.order_status || item.status || 'pending';
}

function getOrderTotal(order: FarmOrder) {
  const item = order as FarmOrder & {
    total_amount?: number | null;
    grand_total?: number | null;
    total?: number | null;
    subtotal?: number | null;
  };

  return item.total_amount ?? item.grand_total ?? item.total ?? item.subtotal ?? null;
}

function getFulfillmentLabel(order: FarmOrder) {
  const item = order as FarmOrder & {
    fulfillment_type?: string | null;
    delivery_method?: string | null;
  };

  return item.fulfillment_type || item.delivery_method || 'Fulfillment pending';
}

function AccountHero({
  displayName,
  email,
  isAdmin,
  farmerStatus,
  onSignOut,
}: {
  displayName: string;
  email?: string;
  isAdmin: boolean;
  farmerStatus?: string | null;
  onSignOut: () => Promise<void>;
}) {
  return (
    <section className="overflow-hidden rounded-[2rem] border border-[#D8E5D4] bg-white shadow-[0_22px_70px_rgba(24,59,40,0.08)]">
      <div className="grid gap-0 lg:grid-cols-[1fr_320px]">
        <div className="relative p-6 sm:p-8 lg:p-10">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_85%_20%,rgba(223,167,90,0.22),transparent_18rem)]" />

          <div className="relative">
            <Badge tone={isAdmin ? 'gold' : 'green'}>
              {isAdmin ? 'Admin access' : farmerStatus || 'Customer account'}
            </Badge>

            <h1 className="mt-4 text-3xl font-black tracking-tight text-[#183B28] sm:text-4xl">
              Welcome back, {displayName}
            </h1>

            <p className="mt-3 max-w-2xl text-sm font-semibold leading-6 text-[#5F6A62] sm:text-base">
              A simple place to manage your orders, My Box, fresh alerts, delivery details, rewards,
              and support for The Harvest Place Ja.
            </p>

            <div className="mt-6 flex flex-wrap gap-3">
              <Button href="/shop">Shop Produce</Button>
              <Button href="/my-box" variant="secondary">
                View My Box
              </Button>
              <Button onClick={onSignOut} variant="ghost">
                <LogOut className="mr-2 h-4 w-4" />
                Sign out
              </Button>
            </div>

            <p className="mt-5 flex items-center gap-2 text-xs font-bold text-[#5F6A62]">
              <UserRound className="h-4 w-4 text-[#2D6741]" />
              {email || 'Secure account'}
            </p>
          </div>
        </div>

        <div className="relative hidden min-h-[280px] bg-[#EAF5E7] lg:block">
          <Image
            src="/logo.png"
            alt="The Harvest Place Ja"
            fill
            className="object-contain p-12 opacity-90"
            sizes="320px"
          />
        </div>
      </div>
    </section>
  );
}

function QuickActions() {
  return (
    <section className="rounded-[2rem] border border-[#D8E5D4] bg-white p-4 shadow-[0_18px_55px_rgba(24,59,40,0.06)] sm:p-5">
      <div className="mb-4 flex flex-col gap-1 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="text-xs font-black uppercase tracking-[0.18em] text-[#DFA75A]">
            Quick actions
          </p>
          <h2 className="text-xl font-black text-[#183B28]">What would you like to do?</h2>
        </div>
        <p className="text-sm font-semibold text-[#5F6A62]">
          No side menu. Just clear buttons that open real pages.
        </p>
      </div>

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
        {quickActions.map(({ title, copy, href, Icon }) => (
          <a
            key={title}
            href={href}
            className="group rounded-3xl border border-[#D8E5D4] bg-[#FFFEFC] p-4 transition hover:-translate-y-0.5 hover:border-[#2D6741]/35 hover:bg-[#EAF5E7] hover:shadow-lg"
          >
            <span className="grid h-11 w-11 place-items-center rounded-2xl bg-[#EAF5E7] text-[#2D6741] transition group-hover:bg-white">
              <Icon className="h-5 w-5" />
            </span>
            <span className="mt-4 block text-sm font-black text-[#183B28]">{title}</span>
            <span className="mt-1 block text-xs font-semibold leading-5 text-[#5F6A62]">{copy}</span>
          </a>
        ))}
      </div>
    </section>
  );
}

function SummaryCard({
  title,
  value,
  copy,
  href,
  Icon,
}: {
  title: string;
  value: string;
  copy: string;
  href: string;
  Icon: typeof Home;
}) {
  return (
    <Card className="border-[#D8E5D4] bg-white p-6 shadow-[0_18px_55px_rgba(24,59,40,0.06)]">
      <div className="flex items-start justify-between gap-4">
        <div>
          <p className="text-sm font-bold text-[#5F6A62]">{title}</p>
          <p className="mt-1 text-3xl font-black text-[#183B28]">{value}</p>
          <p className="mt-2 text-sm font-semibold leading-6 text-[#5F6A62]">{copy}</p>
        </div>

        <div className="grid h-12 w-12 place-items-center rounded-full bg-[#EAF5E7] text-[#2D6741]">
          <Icon className="h-6 w-6" />
        </div>
      </div>

      <Button href={href} variant="secondary" className="mt-5 w-full border-[#D8E5D4]">
        Open
      </Button>
    </Card>
  );
}

function RecentOrders({ orders }: { orders: FarmOrder[] }) {
  return (
    <Card className="border-[#D8E5D4] bg-white p-6 shadow-[0_18px_55px_rgba(24,59,40,0.06)]">
      <div className="mb-5 flex items-center justify-between gap-4">
        <div>
          <p className="text-xs font-black uppercase tracking-[0.18em] text-[#DFA75A]">
            Orders
          </p>
          <h2 className="text-xl font-black text-[#183B28]">Recent orders</h2>
        </div>
        <Button href="/orders" variant="ghost" className="px-3 py-2">
          View all
        </Button>
      </div>

      {orders.length ? (
        <div className="grid gap-3">
          {orders.map((order) => (
            <OrderRow key={order.id} order={order} />
          ))}
        </div>
      ) : (
        <div className="rounded-3xl border border-dashed border-[#D8E5D4] bg-[#F4F9F2] p-8 text-center">
          <PackageCheck className="mx-auto h-10 w-10 text-[#2D6741]" />
          <h3 className="mt-4 text-lg font-black text-[#183B28]">No orders yet</h3>
          <p className="mt-2 text-sm font-semibold text-[#5F6A62]">
            Start by shopping for fresh produce and building your box.
          </p>
          <Button href="/shop" className="mt-5">
            Shop Produce
          </Button>
        </div>
      )}
    </Card>
  );
}

function OrderRow({ order }: { order: FarmOrder }) {
  const status = getOrderStatus(order);
  const total = getOrderTotal(order);

  return (
    <a
      href={`/orders/${order.id}`}
      className="block rounded-3xl border border-[#D8E5D4] bg-[#FFFEFC] p-4 transition hover:border-[#2D6741]/35 hover:bg-[#EAF5E7]"
    >
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <div className="flex flex-wrap items-center gap-2">
            <p className="font-black text-[#183B28]">Order #HPJ-{shortIdLabel(order.id)}</p>
            <StatusChip status={status} />
          </div>
          <p className="mt-1 text-xs font-bold text-[#5F6A62]">
            {formatDate(order.created_at)} • {getFulfillmentLabel(order)} •{' '}
            {typeof total === 'number' ? formatJmd(total) : 'Total pending'}
          </p>
        </div>

        <ChevronRight className="h-5 w-5 text-[#5F6A62]" />
      </div>
    </a>
  );
}

function DeliveryCard({ address }: { address: string }) {
  return (
    <Card className="border-[#D8E5D4] bg-white p-6 shadow-[0_18px_55px_rgba(24,59,40,0.06)]">
      <div className="flex items-start gap-4">
        <div className="grid h-12 w-12 place-items-center rounded-full bg-[#EAF5E7] text-[#2D6741]">
          <MapPin className="h-6 w-6" />
        </div>

        <div>
          <p className="text-xs font-black uppercase tracking-[0.18em] text-[#DFA75A]">
            Delivery details
          </p>
          <h2 className="text-xl font-black text-[#183B28]">Saved area</h2>
        </div>
      </div>

      <div className="mt-5 rounded-3xl border border-[#D8E5D4] bg-[#F4F9F2] p-4">
        <p className="text-sm font-black text-[#183B28]">Primary delivery / pickup area</p>
        <p className="mt-2 whitespace-pre-line text-sm font-semibold leading-6 text-[#5F6A62]">
          {address || 'Add your parish, district, or pickup preference in profile settings below.'}
        </p>
      </div>

      <p className="mt-4 text-xs font-bold leading-5 text-[#5F6A62]">
        Your phone and delivery details are private and are only used for order support.
      </p>
    </Card>
  );
}

function ProfileCard({
  name,
  phone,
  address,
  message,
  saving,
  onName,
  onPhone,
  onAddress,
  onSave,
}: {
  name: string;
  phone: string;
  address: string;
  message: string;
  saving: boolean;
  onName: (value: string) => void;
  onPhone: (value: string) => void;
  onAddress: (value: string) => void;
  onSave: () => Promise<void>;
}) {
  return (
    <Card className="border-[#D8E5D4] bg-white p-6 shadow-[0_18px_55px_rgba(24,59,40,0.06)]">
      <div className="mb-5 flex items-start gap-4">
        <div className="grid h-12 w-12 place-items-center rounded-full bg-[#EAF5E7] text-[#2D6741]">
          <Pencil className="h-6 w-6" />
        </div>

        <div>
          <p className="text-xs font-black uppercase tracking-[0.18em] text-[#DFA75A]">
            Profile
          </p>
          <h2 className="text-xl font-black text-[#183B28]">Update your details</h2>
          <p className="mt-1 text-sm font-semibold text-[#5F6A62]">
            Keep this simple: name, private phone, and delivery area.
          </p>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Field label="Full name" value={name} onChange={onName} />
        <Field label="Private phone" value={phone} onChange={onPhone} placeholder="Only used for order support" />

        <label className="grid gap-2 text-sm font-black text-[#183B28] md:col-span-2">
          Delivery parish / area
          <textarea
            value={address}
            onChange={(event) => onAddress(event.target.value)}
            placeholder="Example: Kingston, Portmore, Mandeville, Montego Bay..."
            className="min-h-24 rounded-2xl border border-[#D8E5D4] bg-white p-3 font-bold outline-none transition placeholder:text-[#5F6A62]/50 focus:border-[#2D6741]/50 focus:ring-4 focus:ring-[#2D6741]/10"
          />
        </label>
      </div>

      {message ? (
        <p className="mt-4 rounded-2xl bg-[#EAF5E7] px-4 py-3 text-sm font-bold text-[#2D6741]">
          {message}
        </p>
      ) : null}

      <Button onClick={onSave} className="mt-5">
        {saving ? 'Saving...' : 'Save Profile'}
      </Button>
    </Card>
  );
}

function SupportAndSecurityCard({
  isAdmin,
  farmerStatus,
  email,
}: {
  isAdmin: boolean;
  farmerStatus?: string | null;
  email?: string;
}) {
  return (
    <Card className="border-[#D8E5D4] bg-white p-6 shadow-[0_18px_55px_rgba(24,59,40,0.06)]">
      <div className="flex items-start gap-4">
        <div className="grid h-12 w-12 place-items-center rounded-full bg-[#EAF5E7] text-[#2D6741]">
          <ShieldCheck className="h-6 w-6" />
        </div>

        <div>
          <p className="text-xs font-black uppercase tracking-[0.18em] text-[#DFA75A]">
            Support & security
          </p>
          <h2 className="text-xl font-black text-[#183B28]">Your account access</h2>
        </div>
      </div>

      <div className="mt-5 grid gap-3">
        <InfoRow label="Email" value={email || 'Not set'} />
        <InfoRow label="Admin" value={isAdmin ? 'Approved' : 'No admin access'} />
        <InfoRow label="Farmer profile" value={farmerStatus || 'No farmer profile'} />
      </div>

      <div className="mt-5 grid gap-3 rounded-3xl bg-[#F4F9F2] p-4">
        <HelpLine
          icon={<Headphones className="h-5 w-5" />}
          title="Need help?"
          copy="Use the support page or live chat widget."
        />
        <HelpLine
          icon={<Truck className="h-5 w-5" />}
          title="Order support"
          copy="Ask about delivery, pickup, payments, or missing items."
        />
      </div>

      <div className="mt-5 flex flex-wrap gap-3">
        <Button href="/support" variant="secondary">
          Open Support
        </Button>
        {isAdmin ? <Button href="/admin">Admin Dashboard</Button> : null}
      </div>
    </Card>
  );
}

function Field({
  label,
  value,
  onChange,
  placeholder,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
}) {
  return (
    <label className="grid gap-2 text-sm font-black text-[#183B28]">
      {label}
      <input
        value={value}
        onChange={(event) => onChange(event.target.value)}
        placeholder={placeholder}
        className="rounded-2xl border border-[#D8E5D4] bg-white p-3 font-bold outline-none transition placeholder:text-[#5F6A62]/50 focus:border-[#2D6741]/50 focus:ring-4 focus:ring-[#2D6741]/10"
      />
    </label>
  );
}

function InfoRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between gap-4 rounded-2xl border border-[#D8E5D4] bg-white px-4 py-3 text-sm font-bold text-[#5F6A62]">
      <span>{label}</span>
      <span className="text-right font-black text-[#183B28]">{value}</span>
    </div>
  );
}

function HelpLine({ icon, title, copy }: { icon: ReactNode; title: string; copy: string }) {
  return (
    <div className="flex gap-3">
      <span className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-white text-[#2D6741]">
        {icon}
      </span>
      <span>
        <span className="block text-sm font-black text-[#183B28]">{title}</span>
        <span className="block text-xs font-semibold leading-5 text-[#5F6A62]">{copy}</span>
      </span>
    </div>
  );
}
