THE HARVEST PLACE JA - ACCOUNT PAGE WORKING SCROLL FIX

What this fixes:
- The sidebar items are now real buttons with onClick handlers.
- They no longer depend on href="#section" anchors.
- Each button calls scrollToAccountSection(sectionId).
- The page scrolls smoothly to the matching topic section.
- My Box now scrolls to a My Box section on the same page instead of leaving the account page.
- The active section is highlighted in the sidebar.
- Mobile users get a horizontal "Jump to" topic bar.

Replace this file:
src/app/account/page.tsx

Then run:
npm run build

If the build passes:
git status
git add -A
git commit -m "Fix account page topic navigation"
git push

Important:
If you are testing locally, restart the dev server after replacing the file:
Ctrl + C
npm run dev

Then hard refresh the browser:
Ctrl + F5
