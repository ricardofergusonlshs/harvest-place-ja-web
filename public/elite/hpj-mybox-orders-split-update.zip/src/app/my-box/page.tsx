'use client';

import Image from 'next/image';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { Minus, Plus, RefreshCcw, ShieldCheck, ShoppingBag, Trash2, Truck } from 'lucide-react';

import { Badge, Button, Card, LoadingState } from '@/components/ui';
import { useAuth } from '@/components/providers/auth-provider';
import { formatJmd } from '@/lib/format';
import { getSupabaseBrowserClient } from '@/lib/supabase/client';

const FALLBACK_IMAGE = '/logo.png';
const DELIVERY_ESTIMATE = 500;
const REFRESH_EVERY_MS = 4000;

type ProductRow = {
  id: string;
  name: string;
  price?: number | null;
  sale_price?: number | null;
  discount_price?: number | null;
  unit?: string | null;
  image_url?: string | null;
  stock_quantity?: number | null;
  is_local?: boolean | null;
  is_organic?: boolean | null;
  farm_name?: string | null;
  farmer_name?: string | null;
  parish?: string | null;
};

type BoxRow = {
  id: string;
  customer_id: string;
  product_id: string;
  quantity: number;
  created_at?: string | null;
  updated_at?: string | null;
  product?: ProductRow | ProductRow[] | null;
};

type BoxLine = {
  id: string;
  customerId: string;
  productId: string;
  quantity: number;
  product: ProductRow;
};

export default function MyBoxPage() {
  const { user, loading: authLoading } = useAuth();

  const [lines, setLines] = useState<BoxLine[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);
  const [message, setMessage] = useState('');

  const loadBox = useCallback(async () => {
    if (!user) {
      setLines([]);
      setLoading(false);
      return;
    }

    const supabase = getSupabaseBrowserClient();

    try {
      setMessage('');

      const { data, error } = await supabase
        .from('customer_box_items')
        .select(
          `
          id,
          customer_id,
          product_id,
          quantity,
          created_at,
          updated_at,
          product:products(*)
        `,
        )
        .eq('customer_id', user.id)
        .order('created_at', { ascending: true });

      if (error) throw error;

      const mapped = ((data || []) as BoxRow[])
        .map((row) => {
          const product = Array.isArray(row.product) ? row.product[0] : row.product;

          if (!product) return null;

          return {
            id: row.id,
            customerId: row.customer_id,
            productId: row.product_id,
            quantity: Number(row.quantity || 1),
            product,
          };
        })
        .filter(Boolean) as BoxLine[];

      setLines(mapped);
      setLastUpdated(new Date());
    } catch (error) {
      console.error('Shared My Box failed to load:', error);
      setMessage(
        error instanceof Error
          ? error.message
          : 'Could not load your shared My Box from Supabase.',
      );
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [user]);

  useEffect(() => {
    if (authLoading) return;

    void loadBox();

    const timer = window.setInterval(() => {
      void loadBox();
    }, REFRESH_EVERY_MS);

    return () => window.clearInterval(timer);
  }, [authLoading, loadBox]);

  useEffect(() => {
    if (!user) return;

    const supabase = getSupabaseBrowserClient();

    const channel = supabase
      .channel(`customer-box-items-${user.id}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'customer_box_items',
          filter: `customer_id=eq.${user.id}`,
        },
        () => {
          void loadBox();
        },
      )
      .subscribe();

    return () => {
      void supabase.removeChannel(channel);
    };
  }, [loadBox, user]);

  const subtotal = useMemo(
    () =>
      lines.reduce((sum, line) => {
        return sum + getProductPrice(line.product) * line.quantity;
      }, 0),
    [lines],
  );

  const count = useMemo(
    () => lines.reduce((sum, line) => sum + line.quantity, 0),
    [lines],
  );

  const deliveryEstimate = subtotal > 0 ? DELIVERY_ESTIMATE : 0;
  const estimatedTotal = subtotal + deliveryEstimate;

  async function refreshNow() {
    setRefreshing(true);
    await loadBox();
  }

  async function updateQuantity(line: BoxLine, quantity: number) {
    if (!user) return;

    const supabase = getSupabaseBrowserClient();

    if (quantity <= 0) {
      await removeLine(line);
      return;
    }

    const previous = lines;
    setLines((current) =>
      current.map((item) => (item.id === line.id ? { ...item, quantity } : item)),
    );

    const { error } = await supabase
      .from('customer_box_items')
      .update({ quantity, updated_at: new Date().toISOString() })
      .eq('id', line.id)
      .eq('customer_id', user.id);

    if (error) {
      setLines(previous);
      setMessage(error.message);
      return;
    }

    void loadBox();
  }

  async function removeLine(line: BoxLine) {
    if (!user) return;

    const supabase = getSupabaseBrowserClient();
    const previous = lines;

    setLines((current) => current.filter((item) => item.id !== line.id));

    const { error } = await supabase
      .from('customer_box_items')
      .delete()
      .eq('id', line.id)
      .eq('customer_id', user.id);

    if (error) {
      setLines(previous);
      setMessage(error.message);
      return;
    }

    void loadBox();
  }

  async function clearBox() {
    if (!user) return;

    const confirmed = window.confirm('Clear all items from your box?');
    if (!confirmed) return;

    const supabase = getSupabaseBrowserClient();
    const previous = lines;

    setLines([]);

    const { error } = await supabase
      .from('customer_box_items')
      .delete()
      .eq('customer_id', user.id);

    if (error) {
      setLines(previous);
      setMessage(error.message);
      return;
    }

    void loadBox();
  }

  if (authLoading || loading) {
    return (
      <main className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
        <LoadingState />
      </main>
    );
  }

  if (!user) {
    return (
      <main className="min-h-screen bg-[#FAF8F0] px-4 py-12 text-[#183B28] sm:px-6 lg:px-8">
        <section className="mx-auto max-w-4xl rounded-[2rem] border border-[#D8E5D4] bg-white p-10 text-center shadow-[0_18px_55px_rgba(24,59,40,0.06)]">
          <ShoppingBag className="mx-auto h-14 w-14 text-[#2D6741]" />
          <h1 className="mt-5 text-3xl font-black">Sign in to view My Box</h1>
          <p className="mx-auto mt-3 max-w-xl text-sm font-semibold leading-6 text-[#5F6A62]">
            Your phone app and website can only share the same cart when you are signed in with the same account.
          </p>
          <div className="mt-6 flex flex-wrap justify-center gap-3">
            <Button href="/auth?redirect=/my-box">Sign in</Button>
            <Button href="/shop" variant="secondary">
              Shop Produce
            </Button>
          </div>
        </section>
      </main>
    );
  }

  if (!lines.length) {
    return (
      <main className="min-h-screen bg-[#FAF8F0] px-4 py-10 text-[#183B28] sm:px-6 lg:px-8">
        <section className="mx-auto max-w-5xl rounded-[2rem] border border-[#D8E5D4] bg-white p-10 text-center shadow-[0_18px_55px_rgba(24,59,40,0.06)]">
          <ShoppingBag className="mx-auto h-14 w-14 text-[#2D6741]" />
          <Badge tone="green" className="mt-4">
            Shared cart ready
          </Badge>
          <h1 className="mt-5 text-3xl font-black">Your box is empty</h1>
          <p className="mx-auto mt-3 max-w-xl text-sm font-semibold leading-6 text-[#5F6A62]">
            Add items from the Android app or website shop. Once both write to the shared Supabase cart, items appear here automatically.
          </p>
          {message ? (
            <p className="mx-auto mt-4 max-w-xl rounded-2xl bg-red-50 px-4 py-3 text-sm font-bold text-red-700">
              {message}
            </p>
          ) : null}
          <div className="mt-6 flex flex-wrap justify-center gap-3">
            <Button href="/shop">Shop Produce</Button>
            <Button href="/orders" variant="secondary">
              Track My Orders Live
            </Button>
            <Button onClick={refreshNow} variant="ghost">
              <RefreshCcw className={refreshing ? 'h-4 w-4 animate-spin' : 'h-4 w-4'} />
              Refresh Box
            </Button>
          </div>
        </section>
      </main>
    );
  }

  return (
    <main className="min-h-screen bg-[#FAF8F0] text-[#183B28]">
      <section className="mx-auto max-w-[1450px] px-4 py-8 sm:px-6 lg:px-10">
        <div className="mb-6 rounded-[2rem] border border-[#D8E5D4] bg-white p-6 shadow-[0_18px_55px_rgba(24,59,40,0.06)]">
          <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
            <div>
              <Badge tone="green">
                <ShoppingBag className="h-3 w-3" />
                Shared My Box
              </Badge>

              <h1 className="mt-4 text-3xl font-black tracking-tight text-[#183B28] sm:text-4xl">
                Shopping Cart
              </h1>

              <p className="mt-2 max-w-2xl text-sm font-semibold leading-6 text-[#5F6A62]">
                Amazon-style cart synced through Supabase. Items added from the app can appear here when the app writes to customer_box_items.
              </p>

              <p className="mt-2 text-xs font-bold text-[#5F6A62]">
                {lastUpdated ? `Last updated ${lastUpdated.toLocaleTimeString()}` : 'Waiting for update'}
              </p>
            </div>

            <div className="flex flex-wrap gap-3">
              <Button href="/shop" variant="secondary">
                Continue Shopping
              </Button>
              <Button href="/orders" variant="ghost">
                Track My Orders Live
              </Button>
              <Button onClick={refreshNow} variant="ghost">
                <RefreshCcw className={refreshing ? 'h-4 w-4 animate-spin' : 'h-4 w-4'} />
                Refresh
              </Button>
            </div>
          </div>

          {message ? (
            <p className="mt-4 rounded-2xl bg-red-50 px-4 py-3 text-sm font-bold text-red-700">
              {message}
            </p>
          ) : null}
        </div>

        <div className="grid gap-6 lg:grid-cols-[1fr_390px]">
          <section className="grid gap-4">
            <Card className="rounded-[1.6rem] border border-[#D8E5D4] bg-white p-5 shadow-[0_14px_40px_rgba(24,59,40,0.05)]">
              <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
                <h2 className="text-2xl font-black text-[#183B28]">
                  Items in your box
                </h2>

                <p className="text-sm font-black text-[#5F6A62]">
                  Subtotal ({count} item{count === 1 ? '' : 's'}):{' '}
                  <span className="text-[#183B28]">{formatJmd(subtotal)}</span>
                </p>
              </div>
            </Card>

            {lines.map((line) => (
              <CartItemCard
                key={line.id}
                line={line}
                onMinus={() => updateQuantity(line, line.quantity - 1)}
                onPlus={() => updateQuantity(line, line.quantity + 1)}
                onRemove={() => removeLine(line)}
              />
            ))}

            <Card className="rounded-[1.6rem] border border-[#D8E5D4] bg-white p-5 shadow-[0_14px_40px_rgba(24,59,40,0.05)]">
              <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                <div>
                  <h3 className="text-lg font-black text-[#183B28]">
                    Want to start over?
                  </h3>
                  <p className="mt-1 text-sm font-semibold text-[#5F6A62]">
                    Clear your shared box on both the website and app.
                  </p>
                </div>

                <button
                  type="button"
                  onClick={clearBox}
                  className="inline-flex items-center justify-center gap-2 rounded-full border border-red-200 bg-red-50 px-5 py-3 text-sm font-black text-red-700 transition hover:bg-red-100"
                >
                  <Trash2 className="h-4 w-4" />
                  Clear Box
                </button>
              </div>
            </Card>
          </section>

          <aside className="space-y-5">
            <Card className="sticky top-32 rounded-[1.8rem] border border-[#D8E5D4] bg-white p-6 shadow-[0_24px_70px_rgba(24,59,40,0.10)]">
              <h2 className="text-2xl font-black text-[#183B28]">
                Order Summary
              </h2>

              <div className="mt-5 grid gap-3 text-sm font-bold text-[#5F6A62]">
                <SummaryRow label={`Items (${count})`} value={formatJmd(subtotal)} />
                <SummaryRow label="Estimated delivery" value={formatJmd(deliveryEstimate)} />
                <SummaryRow label="Pickup option" value="Available at checkout" />

                <div className="mt-2 border-t border-[#D8E5D4] pt-4">
                  <div className="flex items-center justify-between gap-4 text-xl font-black text-[#183B28]">
                    <span>Total</span>
                    <span>{formatJmd(estimatedTotal)}</span>
                  </div>
                  <p className="mt-2 text-xs font-semibold leading-5 text-[#5F6A62]">
                    Final delivery fee and availability are confirmed at checkout.
                  </p>
                </div>
              </div>

              <Button href="/checkout" className="mt-6 w-full">
                Proceed to Checkout
              </Button>

              <Button href="/shop" variant="secondary" className="mt-3 w-full">
                Add More Items
              </Button>
            </Card>

            <Card className="rounded-[1.8rem] border border-[#D8E5D4] bg-[#F4F9F2] p-5">
              <div className="grid gap-3 text-sm font-bold text-[#5F6A62]">
                <TrustLine
                  icon={<ShieldCheck className="h-4 w-4" />}
                  text="Cart syncs through Supabase customer_box_items"
                />
                <TrustLine
                  icon={<Truck className="h-4 w-4" />}
                  text="Orders are tracked live on the Orders page"
                />
              </div>
            </Card>
          </aside>
        </div>
      </section>
    </main>
  );
}

function CartItemCard({
  line,
  onMinus,
  onPlus,
  onRemove,
}: {
  line: BoxLine;
  onMinus: () => void;
  onPlus: () => void;
  onRemove: () => void;
}) {
  const product = line.product;
  const price = getProductPrice(product);
  const lineTotal = price * Number(line.quantity || 0);
  const imageUrl = product.image_url || FALLBACK_IMAGE;

  return (
    <Card className="rounded-[1.8rem] border border-[#D8E5D4] bg-white p-4 shadow-[0_14px_40px_rgba(24,59,40,0.05)] sm:p-5">
      <div className="grid gap-4 md:grid-cols-[150px_1fr_auto] md:items-start">
        <div className="relative h-36 overflow-hidden rounded-3xl border border-[#D8E5D4] bg-[#F4F9F2]">
          <Image
            src={imageUrl}
            alt={product.name}
            fill
            className="object-contain p-3"
            sizes="150px"
          />
        </div>

        <div>
          <div className="flex flex-wrap items-center gap-2">
            {product.is_local ? <Badge tone="green">Local</Badge> : null}
            {product.is_organic ? <Badge tone="gold">Organic</Badge> : null}
          </div>

          <h3 className="mt-3 text-xl font-black text-[#183B28]">
            {product.name}
          </h3>

          <p className="mt-1 text-sm font-semibold text-[#5F6A62]">
            {product.farm_name || product.farmer_name || 'The Harvest Place Ja'}
            {product.parish ? ` • ${product.parish}` : ''}
          </p>

          <p className="mt-2 text-sm font-bold text-[#2D6741]">
            {formatJmd(price)} {product.unit ? `/ ${product.unit}` : ''}
          </p>

          <p className="mt-1 text-xs font-bold text-[#5F6A62]">
            {Number(product.stock_quantity || 0) > 0
              ? `${product.stock_quantity} available`
              : 'Availability will be confirmed'}
          </p>

          <div className="mt-4 flex flex-wrap items-center gap-3">
            <div className="inline-flex items-center overflow-hidden rounded-full border border-[#D8E5D4] bg-white">
              <button
                type="button"
                onClick={onMinus}
                className="grid h-10 w-10 place-items-center text-[#183B28] transition hover:bg-[#EAF5E7]"
                aria-label="Decrease quantity"
              >
                <Minus className="h-4 w-4" />
              </button>

              <span className="min-w-12 px-4 text-center text-sm font-black text-[#183B28]">
                {line.quantity}
              </span>

              <button
                type="button"
                onClick={onPlus}
                className="grid h-10 w-10 place-items-center text-[#183B28] transition hover:bg-[#EAF5E7]"
                aria-label="Increase quantity"
              >
                <Plus className="h-4 w-4" />
              </button>
            </div>

            <button
              type="button"
              onClick={onRemove}
              className="inline-flex items-center gap-2 rounded-full px-3 py-2 text-sm font-black text-red-700 transition hover:bg-red-50"
            >
              <Trash2 className="h-4 w-4" />
              Remove
            </button>
          </div>
        </div>

        <div className="rounded-3xl border border-[#D8E5D4] bg-[#F4F9F2] px-5 py-4 text-left md:min-w-[150px] md:text-right">
          <p className="text-xs font-black uppercase tracking-[0.16em] text-[#5F6A62]">
            Item total
          </p>
          <p className="mt-1 text-xl font-black text-[#183B28]">
            {formatJmd(lineTotal)}
          </p>
        </div>
      </div>
    </Card>
  );
}

function getProductPrice(product: ProductRow) {
  return Number(product.sale_price ?? product.discount_price ?? product.price ?? 0);
}

function SummaryRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between gap-4">
      <span>{label}</span>
      <span className="font-black text-[#183B28]">{value}</span>
    </div>
  );
}

function TrustLine({ icon, text }: { icon: React.ReactNode; text: string }) {
  return (
    <div className="flex items-center gap-3">
      <span className="grid h-9 w-9 place-items-center rounded-full bg-white text-[#2D6741]">
        {icon}
      </span>
      <span>{text}</span>
    </div>
  );
}
