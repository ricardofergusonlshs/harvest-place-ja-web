# HPJ My Box / Orders Split Update

This update separates the two jobs correctly:

## 1. My Box = Amazon-style cart
File:
src/app/my-box/page.tsx

This reads from a shared Supabase table:
customer_box_items

It shows:
- cart item cards
- product image
- quantity minus/plus
- remove item
- clear box
- checkout summary
- refresh every 4 seconds
- realtime subscription when enabled

## 2. Orders = Live order tracker
File:
src/app/orders/page.tsx

This reads from:
orders

It shows:
- live order status
- pending / preparing / ready / delivered
- refresh every 4 seconds

## 3. Supabase table
Run:
supabase/customer_box_items.sql

## Very important
The Android app must write cart items to `customer_box_items`.
If the phone app still stores its cart locally, the website cannot see it.

The Android app should upsert rows like:

customer_id = Supabase auth user id
product_id = product id
quantity = selected quantity

Unique key:
(customer_id, product_id)

## Install
Copy the `src` folder into your project root, replacing the files.

Then run:

npm run build

If successful:

npm run dev

Then check:

http://localhost:3000/my-box
http://localhost:3000/orders
