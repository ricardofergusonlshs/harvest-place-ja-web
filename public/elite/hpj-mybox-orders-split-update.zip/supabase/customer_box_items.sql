-- Shared My Box / cloud cart table for The Harvest Place Ja
-- Run this in Supabase SQL Editor.

create table if not exists public.customer_box_items (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid not null references auth.users(id) on delete cascade,
  product_id uuid not null references public.products(id) on delete cascade,
  quantity integer not null default 1 check (quantity > 0),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (customer_id, product_id)
);

alter table public.customer_box_items enable row level security;

drop policy if exists "Customers can read their own box items" on public.customer_box_items;
drop policy if exists "Customers can insert their own box items" on public.customer_box_items;
drop policy if exists "Customers can update their own box items" on public.customer_box_items;
drop policy if exists "Customers can delete their own box items" on public.customer_box_items;

create policy "Customers can read their own box items"
on public.customer_box_items
for select
to authenticated
using (auth.uid() = customer_id);

create policy "Customers can insert their own box items"
on public.customer_box_items
for insert
to authenticated
with check (auth.uid() = customer_id);

create policy "Customers can update their own box items"
on public.customer_box_items
for update
to authenticated
using (auth.uid() = customer_id)
with check (auth.uid() = customer_id);

create policy "Customers can delete their own box items"
on public.customer_box_items
for delete
to authenticated
using (auth.uid() = customer_id);

create or replace function public.set_customer_box_items_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists customer_box_items_set_updated_at on public.customer_box_items;

create trigger customer_box_items_set_updated_at
before update on public.customer_box_items
for each row
execute function public.set_customer_box_items_updated_at();

-- Optional realtime. If this errors because the table is already added, ignore it.
alter publication supabase_realtime add table public.customer_box_items;
